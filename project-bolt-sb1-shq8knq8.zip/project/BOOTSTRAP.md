# Bootstrap Guide - News SEO Analyzer

This guide will help you get the News SEO Analyzer up and running from scratch.

## Prerequisites

Make sure you have:
- Node.js 18 or higher
- npm (comes with Node.js)

Check your versions:
```bash
node --version  # Should be v18.x or higher
npm --version   # Should be 9.x or higher
```

## Step-by-Step Setup

### 1. Install All Dependencies

Run this from the project root:

```bash
npm run install:all
```

This will install:
- Frontend dependencies in the root directory
- Backend dependencies in the `server/` directory

**Expected output:**
```
✓ Frontend dependencies installed
✓ Backend dependencies installed
```

### 2. Verify Environment Configuration

Check that `.env` file exists in the project root:

```bash
cat .env
```

You should see:
```env
VITE_SUPABASE_URL=https://...
VITE_SUPABASE_ANON_KEY=...
VITE_API_URL=http://localhost:3001
PORT=3001
CRAWL_LIMIT_DEFAULT=10
```

If any values are missing, the backend will not start.

### 3. Start the Backend Server

Open a terminal and run:

```bash
cd server
npm start
```

**Expected output:**
```
🔧 Starting News SEO Analyzer Backend...
✅ Server started successfully
   Port: 3001
   URL: http://localhost:3001

🔍 Checking database connection...
✅ Database connected

📡 API Endpoints:
   Health Check: http://localhost:3001/health
   Websites API: http://localhost:3001/api/websites
   Crawl API: http://localhost:3001/api/crawl

🚀 Backend is ready!
```

**If you see errors:**

#### Error: "Missing required environment variables"
- Check your `.env` file in the project root
- Ensure `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` are set

#### Error: "Backend dependencies not installed"
- Run: `cd server && npm install`
- Then try starting again

#### Error: "Cannot find package 'express'"
- Delete `server/node_modules` and `server/package-lock.json`
- Run: `cd server && npm install`
- Try starting again

#### Database connection failed
- Check your Supabase credentials in `.env`
- Verify your internet connection
- The backend will still start, but database operations will fail

### 4. Start the Frontend

Open a **NEW terminal** (keep the backend running!) and run:

```bash
npm run dev
```

**Expected output:**
```
VITE v5.4.8  ready in 342 ms

➜  Local:   http://localhost:5173/
➜  Network: use --host to expose
```

### 5. Access the Application

Open your browser and go to:
```
http://localhost:5173
```

You should see:
- The News SEO Analyzer interface
- Status indicators in the header:
  - **Backend: Online** ✅ (green)
  - **DB: Connected** ✅ (green)

**If you see:**
- **Backend: Offline** ❌ → The backend server is not running or not reachable
- **Backend: Checking...** → Health check is in progress
- **DB: Disconnected** → Backend is running but can't connect to Supabase

### 6. Verify Everything Works

#### Test Backend Health
Open a new terminal and run:
```bash
curl http://localhost:3001/health
```

**Expected response:**
```json
{
  "backend": "ok",
  "database": "connected",
  "timestamp": "2024-02-09T12:00:00.000Z",
  "uptime": 5.123,
  "version": "1.0.0"
}
```

#### Test in Browser
1. Click "Add Website"
2. Enter a domain (e.g., `techcrunch.com`)
3. Click "Add Website"
4. You should see the website appear in your dashboard

## Common Issues and Solutions

### Issue: Port 3001 Already in Use

**Solution:**
```bash
# Find what's using port 3001
lsof -i :3001

# Kill the process (replace PID with actual process ID)
kill -9 PID

# Or change the port in .env
PORT=3002
VITE_API_URL=http://localhost:3002
```

Then restart both frontend and backend.

### Issue: "Failed to fetch" in Browser

**Possible causes:**
1. Backend not running → Start with `cd server && npm start`
2. Wrong API URL → Check `VITE_API_URL` in `.env`
3. CORS issue → Backend should allow all origins by default

### Issue: Dependencies Keep Disappearing

**Solution:**
Make sure you're not deleting `node_modules` folders:
- Root `node_modules/` is for frontend
- `server/node_modules/` is for backend

Both are needed!

### Issue: TypeScript Errors

**Solution:**
```bash
# Check for type errors
npm run typecheck

# Usually these don't prevent the app from running
# Fix them if needed, but they won't block development
```

### Issue: Build Fails

**Solution:**
```bash
# Clear everything and reinstall
rm -rf node_modules server/node_modules dist
npm install
cd server && npm install
cd ..
npm run build
```

## Development Workflow

### Normal Development

**Terminal 1** - Backend:
```bash
cd server
npm start
```

**Terminal 2** - Frontend:
```bash
npm run dev
```

Keep both running while developing.

### Making Changes

**Frontend changes** (src/\*.tsx):
- Saved automatically
- Browser reloads automatically
- No restart needed

**Backend changes** (server/\*.js):
- Kill server (Ctrl+C)
- Restart with `npm start`
- Or use `npm run dev` for auto-restart

### Building for Production

```bash
# Build frontend
npm run build

# Test production build
npm run preview

# Deploy (see DEPLOYMENT.md)
```

## Quick Commands Reference

```bash
# Install all dependencies
npm run install:all

# Start backend
cd server && npm start

# Start frontend (in new terminal)
npm run dev

# Build for production
npm run build

# Run type checking
npm run typecheck

# Check health
curl http://localhost:3001/health

# View backend logs
# Just look at the terminal where you ran npm start
```

## System Status Indicators

The app shows real-time status in the header:

| Indicator | Meaning | Action |
|-----------|---------|--------|
| Backend: Online ✅ | Backend running and healthy | None needed |
| Backend: Offline ❌ | Backend not reachable | Start backend server |
| Backend: Checking... | Health check in progress | Wait a moment |
| DB: Connected ✅ | Database working | None needed |
| DB: Disconnected ❌ | Database not reachable | Check Supabase credentials |

## Getting Help

If you're stuck:

1. **Check terminal output** for error messages
2. **Check browser console** (F12) for frontend errors
3. **Test health endpoint** with curl
4. **Verify .env file** has all required values
5. **Reinstall dependencies** if nothing else works

## Success Checklist

You're ready when:
- [ ] Backend starts without errors
- [ ] Frontend opens in browser
- [ ] Status shows "Backend: Online"
- [ ] Status shows "DB: Connected"
- [ ] You can add a test website
- [ ] Health endpoint returns valid JSON

---

**Need more help?** Check:
- [README.md](./README.md) - Full documentation
- [QUICKSTART.md](./QUICKSTART.md) - 5-minute guide
- [DEPLOYMENT.md](./DEPLOYMENT.md) - Production deployment

## Pro Tips

1. **Use two terminal tabs/windows** - One for backend, one for frontend
2. **Check backend logs first** if something breaks
3. **Browser DevTools (F12)** shows frontend errors
4. **Health endpoint** is your friend for debugging
5. **Environment variables** must be set before starting servers
6. **Restart backend after .env changes**
7. **Frontend hot-reloads**, backend doesn't
