import dotenv from 'dotenv';
dotenv.config();

/**
 * Centralized Feature Flags Configuration
 *
 * Controls which optional integrations are enabled based on environment variables
 * and validates required credentials are present when features are enabled.
 */

// Feature flag helpers
export const isGscEnabled = () => {
  const enabled = process.env.ENABLE_GSC === 'true';
  if (enabled) {
    return hasGscCredentials();
  }
  return false;
};

export const isMozEnabled = () => {
  const enabled = process.env.ENABLE_MOZ === 'true';
  if (enabled) {
    return hasMozCredentials();
  }
  return false;
};

export const isOpenAiEnabled = () => {
  const enabled = process.env.ENABLE_OPENAI === 'true';
  if (enabled) {
    return hasOpenAiCredentials();
  }
  return false;
};

// Credential validation
export const hasGscCredentials = () => {
  return !!(
    process.env.GSC_CLIENT_ID &&
    process.env.GSC_CLIENT_SECRET &&
    process.env.GSC_REDIRECT_URI
  );
};

export const hasMozCredentials = () => {
  return !!(
    process.env.MOZ_ACCESS_ID &&
    process.env.MOZ_SECRET_KEY
  );
};

export const hasOpenAiCredentials = () => {
  return !!process.env.OPENAI_API_KEY;
};

// Get all feature statuses
export const getFeatureConfig = () => {
  return {
    gsc: {
      enabled: isGscEnabled(),
      hasCredentials: hasGscCredentials(),
      status: isGscEnabled() ? 'enabled' : 'disabled'
    },
    moz: {
      enabled: isMozEnabled(),
      hasCredentials: hasMozCredentials(),
      status: isMozEnabled() ? 'enabled' : 'disabled'
    },
    openai: {
      enabled: isOpenAiEnabled(),
      hasCredentials: hasOpenAiCredentials(),
      status: isOpenAiEnabled() ? 'enabled' : 'disabled'
    }
  };
};

// Get configuration warnings for missing credentials
export const getConfigWarnings = () => {
  const warnings = [];

  if (process.env.ENABLE_GSC === 'true' && !hasGscCredentials()) {
    warnings.push('GSC is enabled but credentials are missing (GSC_CLIENT_ID, GSC_CLIENT_SECRET, GSC_REDIRECT_URI)');
  }

  if (process.env.ENABLE_MOZ === 'true' && !hasMozCredentials()) {
    warnings.push('Moz is enabled but credentials are missing (MOZ_ACCESS_ID, MOZ_SECRET_KEY)');
  }

  if (process.env.ENABLE_OPENAI === 'true' && !hasOpenAiCredentials()) {
    warnings.push('OpenAI is enabled but API key is missing (OPENAI_API_KEY)');
  }

  return warnings;
};

// Validate required environment variables
export const validateRequiredConfig = () => {
  const required = [
    'VITE_SUPABASE_URL',
    'VITE_SUPABASE_ANON_KEY',
    'PORT'
  ];

  const missing = required.filter(key => !process.env[key]);

  if (missing.length > 0) {
    throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
  }
};

// Log feature status on startup
export const logFeatureStatus = () => {
  const features = getFeatureConfig();
  const warnings = getConfigWarnings();

  console.log('\n🎯 Feature Configuration:');
  console.log(`   Google Search Console: ${features.gsc.status}`);
  console.log(`   Moz API: ${features.moz.status}`);
  console.log(`   OpenAI: ${features.openai.status}`);

  if (warnings.length > 0) {
    console.log('\n⚠️  Configuration Warnings:');
    warnings.forEach(warning => console.log(`   - ${warning}`));
  }

  console.log('');
};

export default {
  isGscEnabled,
  isMozEnabled,
  isOpenAiEnabled,
  hasGscCredentials,
  hasMozCredentials,
  hasOpenAiCredentials,
  getFeatureConfig,
  getConfigWarnings,
  validateRequiredConfig,
  logFeatureStatus
};
