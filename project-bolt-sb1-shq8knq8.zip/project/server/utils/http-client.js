import * as cheerio from 'cheerio';
import { normalizeUrl, isValidInternalUrl } from './url-utils.js';

export async function fetchPage(url, baseUrl) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000);

  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'SEO-Analysis-Bot/1.0'
      },
      redirect: 'follow'
    });

    clearTimeout(timeout);

    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('text/html')) {
      throw new Error('Not an HTML page');
    }

    const html = await response.text();
    const $ = cheerio.load(html);

    const title = $('title').first().text().trim();
    const metaRobots = $('meta[name="robots"]').attr('content') || null;
    const xRobotsTag = response.headers.get('x-robots-tag') || null;

    const canonicalUrl = $('link[rel="canonical"]').attr('href') || null;
    let canonicalStatus = null;

    if (canonicalUrl) {
      try {
        const canonicalResponse = await fetch(canonicalUrl, {
          method: 'HEAD',
          signal: AbortSignal.timeout(10000)
        });
        canonicalStatus = canonicalResponse.status;
      } catch (e) {
        canonicalStatus = 0;
      }
    }

    const h1Tags = [];
    $('h1').each((i, el) => {
      const text = $(el).text().trim();
      if (text) h1Tags.push(text);
    });

    const bodyText = $('body').text()
      .replace(/\s+/g, ' ')
      .trim();
    const wordCount = bodyText.split(' ').filter(w => w.length > 0).length;

    const hasVideoEmbed = $('video, iframe[src*="youtube"], iframe[src*="vimeo"]').length > 0;

    const schemaTypes = [];
    $('script[type="application/ld+json"]').each((i, el) => {
      try {
        const json = JSON.parse($(el).html());
        if (json['@type']) {
          schemaTypes.push(json['@type']);
        }
      } catch (e) {
        // Invalid JSON, skip
      }
    });

    const internalLinks = [];
    $('a[href]').each((i, el) => {
      const href = $(el).attr('href');
      if (href) {
        const normalizedHref = normalizeUrl(href, baseUrl);
        if (normalizedHref && isValidInternalUrl(normalizedHref, baseUrl) && !internalLinks.includes(normalizedHref)) {
          internalLinks.push(normalizedHref);
        }
      }
    });

    return {
      status: response.status,
      title,
      metaRobots,
      xRobotsTag,
      canonicalUrl,
      canonicalStatus,
      h1Tags,
      wordCount,
      hasVideoEmbed,
      schemaTypes,
      internalLinks: internalLinks.slice(0, 100)
    };

  } catch (error) {
    clearTimeout(timeout);

    if (error.name === 'AbortError') {
      throw new Error('Request timeout after 30 seconds');
    }

    throw error;
  }
}
