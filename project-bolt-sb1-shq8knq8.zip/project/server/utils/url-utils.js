export function classifyPageType(url, pageData) {
  const urlLower = url.toLowerCase();

  if (urlLower.includes('/amp/') || urlLower.includes('/amp') || urlLower.includes('?amp=1') || urlLower.includes('&amp=1')) {
    return 'amp';
  }

  const hasSearchParam = urlLower.includes('?q=') || urlLower.includes('&q=') ||
    urlLower.includes('?s=') || urlLower.includes('&s=') ||
    urlLower.includes('?query=') || urlLower.includes('&query=') ||
    urlLower.includes('?search=') || urlLower.includes('&search=') ||
    urlLower.includes('/search');

  const hasPaginationParam = urlLower.includes('page=') || urlLower.includes('/page/');

  if (hasSearchParam && hasPaginationParam) {
    return 'search_pagination';
  }

  if (hasSearchParam) {
    return 'search';
  }

  if (hasPaginationParam) {
    const pageNum = extractPageNumber(url);
    if (pageNum > 1) {
      return 'pagination';
    }
  }

  if (urlLower.includes('/tag/') || urlLower.includes('/tags/')) {
    return 'tag';
  }

  if (urlLower.includes('/category/') || urlLower.includes('/section/') || urlLower.includes('/topic/')) {
    return 'category';
  }

  if (urlLower.match(/\/\d{4}\/\d{2}\//) || urlLower.includes('/article/') || urlLower.includes('/news/') || urlLower.includes('/post/')) {
    return 'article';
  }

  if (pageData && pageData.schemaTypes) {
    const schemaTypes = pageData.schemaTypes || [];
    if (schemaTypes.includes('Article') || schemaTypes.includes('NewsArticle')) {
      return 'article';
    }
  }

  return 'unknown';
}

export function normalizeUrl(url, baseUrl) {
  try {
    if (url.startsWith('//')) {
      url = 'https:' + url;
    } else if (url.startsWith('/')) {
      url = baseUrl + url;
    } else if (!url.startsWith('http')) {
      url = baseUrl + '/' + url;
    }

    const urlObj = new URL(url);

    urlObj.hash = '';

    const params = new URLSearchParams(urlObj.search);
    const filteredParams = new URLSearchParams();

    for (const [key, value] of params.entries()) {
      const keyLower = key.toLowerCase();
      if (!keyLower.includes('utm_') &&
          !keyLower.includes('fbclid') &&
          !keyLower.includes('gclid') &&
          !keyLower.includes('ref')) {
        filteredParams.append(key, value);
      }
    }

    urlObj.search = filteredParams.toString();

    return urlObj.toString().replace(/\/$/, '');
  } catch (e) {
    return null;
  }
}

export function isValidInternalUrl(url, baseUrl) {
  try {
    const urlObj = new URL(url);
    const baseObj = new URL(baseUrl);

    if (urlObj.hostname !== baseObj.hostname) {
      return false;
    }

    const ext = urlObj.pathname.toLowerCase().split('.').pop();
    const excludedExtensions = ['pdf', 'jpg', 'jpeg', 'png', 'gif', 'svg', 'css', 'js', 'xml', 'zip', 'mp4', 'mp3'];
    if (excludedExtensions.includes(ext)) {
      return false;
    }

    return true;
  } catch (e) {
    return false;
  }
}

function extractPageNumber(url) {
  const pageMatch = url.match(/[?&]page=(\d+)/i) || url.match(/\/page\/(\d+)/i);
  return pageMatch ? parseInt(pageMatch[1]) : 1;
}

export function extractDomain(url) {
  try {
    const urlObj = new URL(url);
    return urlObj.hostname;
  } catch (e) {
    return null;
  }
}
