#!/bin/bash

# News SEO Analyzer Backend Startup Script

cd "$(dirname "$0")"

echo "🔧 News SEO Analyzer - Backend Startup"
echo "======================================"
echo ""

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
    echo ""
fi

# Kill any existing processes on port 3001
echo "🧹 Cleaning up existing processes..."
pkill -f "node index.js" 2>/dev/null || true
sleep 1

# Start the server
echo "🚀 Starting backend server..."
node index.js

# This script will keep running as long as the node process runs
