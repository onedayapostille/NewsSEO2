import express from 'express';
import { supabase } from '../config/supabase.js';

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const { data: websites, error } = await supabase
      .from('websites')
      .select(`
        *,
        crawl_sessions (
          id,
          started_at,
          finished_at,
          status,
          pages_crawled,
          total_issues,
          critical_issues
        )
      `)
      .order('created_at', { ascending: false });

    if (error) throw error;

    const websitesWithLatest = websites.map(website => {
      const sessions = website.crawl_sessions || [];
      const latestSession = sessions.sort((a, b) =>
        new Date(b.started_at) - new Date(a.started_at)
      )[0];

      return {
        ...website,
        latest_session: latestSession || null,
        crawl_sessions: undefined
      };
    });

    res.json(websitesWithLatest);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const { data: website, error } = await supabase
      .from('websites')
      .select('*')
      .eq('id', req.params.id)
      .maybeSingle();

    if (error) throw error;
    if (!website) {
      return res.status(404).json({ error: 'Website not found' });
    }

    const { data: sessions } = await supabase
      .from('crawl_sessions')
      .select('*')
      .eq('website_id', req.params.id)
      .order('started_at', { ascending: false });

    res.json({ ...website, sessions: sessions || [] });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const { domain, display_name } = req.body;

    if (!domain) {
      return res.status(400).json({ error: 'Domain is required' });
    }

    const normalizedDomain = domain.replace(/^(https?:\/\/)?(www\.)?/, '').replace(/\/$/, '');

    const { data: website, error } = await supabase
      .from('websites')
      .insert({
        domain: normalizedDomain,
        display_name: display_name || normalizedDomain,
        site_type: 'news'
      })
      .select()
      .single();

    if (error) throw error;

    res.status(201).json(website);
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Website already exists' });
    }
    res.status(500).json({ error: error.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const { error } = await supabase
      .from('websites')
      .delete()
      .eq('id', req.params.id);

    if (error) throw error;

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
