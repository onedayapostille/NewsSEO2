import express from 'express';
import { supabase } from '../config/supabase.js';
import { isGscEnabled } from '../config/features.js';
import {
  exchangeCodeForToken,
  fetchCoverageData,
  fetchTopPages,
  fetchTopQueries
} from '../services/gscService.js';

const router = express.Router();

router.get('/auth-url/:websiteId', async (req, res) => {
  try {
    if (!isGscEnabled()) {
      return res.status(503).json({
        error: 'GSC integration disabled',
        message: 'Set ENABLE_GSC=true and configure GSC credentials to enable this feature'
      });
    }

    const clientId = process.env.GSC_CLIENT_ID;
    const redirectUri = process.env.GSC_REDIRECT_URI;

    if (!clientId || !redirectUri) {
      return res.status(503).json({
        error: 'Google Search Console not configured',
        message: 'GSC_CLIENT_ID and GSC_REDIRECT_URI environment variables are required'
      });
    }

    const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
      `client_id=${clientId}&` +
      `redirect_uri=${encodeURIComponent(redirectUri)}&` +
      `response_type=code&` +
      `scope=https://www.googleapis.com/auth/webmasters.readonly&` +
      `access_type=offline&` +
      `state=${req.params.websiteId}&` +
      `prompt=consent`;

    res.json({ authUrl });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/callback', async (req, res) => {
  try {
    if (!isGscEnabled()) {
      return res.status(503).json({
        error: 'GSC integration disabled'
      });
    }

    const { code, websiteId } = req.body;

    if (!code || !websiteId) {
      return res.status(400).json({
        error: 'Missing required parameters: code and websiteId'
      });
    }

    console.log('Exchanging authorization code for tokens...');
    const tokens = await exchangeCodeForToken(code);

    const { data: website } = await supabase
      .from('websites')
      .select('domain')
      .eq('id', websiteId)
      .single();

    const propertyUrl = `sc-domain:${website.domain}`;
    const expiresAt = new Date(Date.now() + 3600 * 1000).toISOString();

    const { error: updateError } = await supabase
      .from('websites')
      .update({
        gsc_connected: true,
        gsc_property_url: propertyUrl,
        gsc_access_token: tokens.access_token,
        gsc_refresh_token: tokens.refresh_token,
        gsc_token_expires_at: expiresAt
      })
      .eq('id', websiteId);

    if (updateError) throw updateError;

    res.json({
      success: true,
      message: 'Google Search Console connected successfully'
    });
  } catch (error) {
    console.error('GSC callback error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

router.post('/fetch/:websiteId', async (req, res) => {
  try {
    if (!isGscEnabled()) {
      return res.status(503).json({
        error: 'GSC integration disabled'
      });
    }

    const { data: website } = await supabase
      .from('websites')
      .select('gsc_property_url, gsc_connected')
      .eq('id', req.params.websiteId)
      .single();

    if (!website?.gsc_connected) {
      return res.status(400).json({
        error: 'GSC not connected for this website'
      });
    }

    console.log(`Fetching GSC data for website ${req.params.websiteId}...`);

    const [coverage, topPages, topQueries] = await Promise.all([
      fetchCoverageData(req.params.websiteId, website.gsc_property_url),
      fetchTopPages(req.params.websiteId, website.gsc_property_url),
      fetchTopQueries(req.params.websiteId, website.gsc_property_url)
    ]);

    const { data: gscData, error } = await supabase
      .from('gsc_data')
      .insert({
        website_id: req.params.websiteId,
        indexed_pages: coverage.indexed_pages,
        excluded_pages: coverage.excluded_pages,
        errors: coverage.errors,
        top_pages: topPages,
        top_queries: topQueries,
        data_source: coverage.source,
        fetched_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error) throw error;

    res.json(gscData);
  } catch (error) {
    console.error('GSC fetch error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

router.get('/data/:websiteId', async (req, res) => {
  try {
    const { data: gscData, error } = await supabase
      .from('gsc_data')
      .select('*')
      .eq('website_id', req.params.websiteId)
      .order('fetched_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) throw error;

    res.json(gscData || null);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.delete('/disconnect/:websiteId', async (req, res) => {
  try {
    await supabase
      .from('websites')
      .update({
        gsc_connected: false,
        gsc_property_url: null,
        gsc_access_token: null,
        gsc_refresh_token: null,
        gsc_token_expires_at: null
      })
      .eq('id', req.params.websiteId);

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
