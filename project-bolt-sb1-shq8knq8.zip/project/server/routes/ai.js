import express from 'express';
import { supabase } from '../config/supabase.js';
import { isOpenAiEnabled } from '../config/features.js';
import {
  generateRecommendations,
  generateTaskList,
  generateExecutiveSummary
} from '../services/openaiService.js';

const router = express.Router();

// Rate limiting cache (simple in-memory, use Redis in production)
const rateLimitCache = new Map();

function checkRateLimit(sessionId) {
  const now = Date.now();
  const lastRequest = rateLimitCache.get(sessionId);

  if (lastRequest && now - lastRequest < 60000) { // 1 minute
    return false;
  }

  rateLimitCache.set(sessionId, now);
  return true;
}

router.post('/recommendations/:sessionId', async (req, res) => {
  try {
    if (!isOpenAiEnabled()) {
      return res.status(503).json({
        error: 'AI features disabled',
        message: 'Set ENABLE_OPENAI=true and configure OPENAI_API_KEY to enable AI-powered recommendations'
      });
    }

    if (!checkRateLimit(req.params.sessionId)) {
      return res.status(429).json({
        error: 'Rate limit exceeded',
        message: 'Please wait 1 minute between AI requests'
      });
    }

    const { data: issues, error: issuesError } = await supabase
      .from('crawl_issues')
      .select('*')
      .eq('session_id', req.params.sessionId)
      .limit(50);

    if (issuesError) throw issuesError;

    if (!issues || issues.length === 0) {
      return res.json({
        recommendations: [],
        summary: 'No issues found to analyze'
      });
    }

    console.log(`Generating AI recommendations for ${issues.length} issues...`);
    const recommendations = await generateRecommendations(issues);

    res.json(recommendations);
  } catch (error) {
    console.error('AI recommendations error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

router.post('/tasks/:sessionId', async (req, res) => {
  try {
    if (!isOpenAiEnabled()) {
      return res.status(503).json({
        error: 'AI features disabled'
      });
    }

    if (!checkRateLimit(req.params.sessionId)) {
      return res.status(429).json({
        error: 'Rate limit exceeded',
        message: 'Please wait 1 minute between AI requests'
      });
    }

    const format = req.body.format || 'clickup';

    const { data: issues, error: issuesError } = await supabase
      .from('crawl_issues')
      .select('*')
      .eq('session_id', req.params.sessionId)
      .order('severity', { ascending: true })
      .limit(30);

    if (issuesError) throw issuesError;

    if (!issues || issues.length === 0) {
      return res.json({
        format,
        tasks: [],
        total: 0
      });
    }

    console.log(`Generating task list in ${format} format...`);
    const taskList = await generateTaskList(issues, format);

    res.json(taskList);
  } catch (error) {
    console.error('AI task generation error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

router.post('/summary/:sessionId', async (req, res) => {
  try {
    if (!isOpenAiEnabled()) {
      return res.status(503).json({
        error: 'AI features disabled'
      });
    }

    if (!checkRateLimit(req.params.sessionId)) {
      return res.status(429).json({
        error: 'Rate limit exceeded',
        message: 'Please wait 1 minute between AI requests'
      });
    }

    const { data: session, error: sessionError } = await supabase
      .from('crawl_sessions')
      .select(`
        *,
        crawl_pages(count),
        crawl_issues(count, severity)
      `)
      .eq('id', req.params.sessionId)
      .single();

    if (sessionError) throw sessionError;

    const { data: issues } = await supabase
      .from('crawl_issues')
      .select('severity')
      .eq('session_id', req.params.sessionId);

    const crawlData = {
      total_pages: session.crawl_pages?.[0]?.count || 0,
      critical_issues: issues?.filter(i => i.severity === 'critical').length || 0,
      high_issues: issues?.filter(i => i.severity === 'high').length || 0,
      medium_issues: issues?.filter(i => i.severity === 'medium').length || 0,
      low_issues: issues?.filter(i => i.severity === 'low').length || 0
    };

    console.log('Generating executive summary...');
    const summary = await generateExecutiveSummary(crawlData);

    res.json(summary);
  } catch (error) {
    console.error('AI summary generation error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

router.get('/status', (req, res) => {
  res.json({
    enabled: isOpenAiEnabled(),
    model: process.env.OPENAI_MODEL || 'gpt-3.5-turbo',
    available_endpoints: [
      '/api/ai/recommendations/:sessionId',
      '/api/ai/tasks/:sessionId',
      '/api/ai/summary/:sessionId'
    ]
  });
});

export default router;
