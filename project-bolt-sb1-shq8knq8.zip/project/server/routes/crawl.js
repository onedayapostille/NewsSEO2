import express from 'express';
import { supabase } from '../config/supabase.js';
import { startCrawl } from '../services/crawler.js';

const router = express.Router();

router.post('/start', async (req, res) => {
  try {
    const { website_id, crawl_limit = 10 } = req.body;

    if (!website_id) {
      return res.status(400).json({ error: 'website_id is required' });
    }

    const { data: session, error } = await supabase
      .from('crawl_sessions')
      .insert({
        website_id,
        crawl_limit,
        status: 'queued'
      })
      .select()
      .single();

    if (error) throw error;

    startCrawl(session.id, website_id, crawl_limit);

    res.status(201).json(session);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/session/:id', async (req, res) => {
  try {
    const { data: session, error } = await supabase
      .from('crawl_sessions')
      .select('*')
      .eq('id', req.params.id)
      .maybeSingle();

    if (error) throw error;
    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }

    res.json(session);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/session/:id/pages', async (req, res) => {
  try {
    const { page_type, severity } = req.query;

    let query = supabase
      .from('pages')
      .select('*')
      .eq('crawl_session_id', req.params.id)
      .order('created_at', { ascending: true });

    if (page_type) {
      query = query.eq('page_type', page_type);
    }

    const { data: pages, error } = await query;

    if (error) throw error;

    res.json(pages || []);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/session/:id/issues', async (req, res) => {
  try {
    const { severity, issue_type } = req.query;

    let query = supabase
      .from('seo_issues')
      .select('*')
      .eq('crawl_session_id', req.params.id)
      .order('severity', { ascending: true })
      .order('created_at', { ascending: true });

    if (severity) {
      query = query.eq('severity', severity);
    }

    if (issue_type) {
      query = query.eq('issue_type', issue_type);
    }

    const { data: issues, error } = await query;

    if (error) throw error;

    res.json(issues || []);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/session/:id/export', async (req, res) => {
  try {
    const { format = 'json' } = req.query;

    const { data: session } = await supabase
      .from('crawl_sessions')
      .select('*')
      .eq('id', req.params.id)
      .maybeSingle();

    const { data: pages } = await supabase
      .from('pages')
      .select('*')
      .eq('crawl_session_id', req.params.id);

    const { data: issues } = await supabase
      .from('seo_issues')
      .select('*')
      .eq('crawl_session_id', req.params.id);

    if (format === 'csv') {
      const csv = generateCSV(pages, issues);
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="seo-report-${req.params.id}.csv"`);
      res.send(csv);
    } else {
      res.json({
        session,
        pages,
        issues
      });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

function generateCSV(pages, issues) {
  const headers = ['URL', 'Page Type', 'HTTP Status', 'Title', 'Meta Robots', 'Canonical URL', 'H1 Count', 'Word Count', 'Issue Severity', 'Issue Type', 'Issue Description', 'Recommended Fix'];

  const rows = issues.map(issue => {
    const page = pages.find(p => p.id === issue.page_id) || {};
    return [
      issue.url || page.url || '',
      page.page_type || '',
      page.http_status || '',
      (page.title || '').replace(/"/g, '""'),
      page.meta_robots || '',
      page.canonical_url || '',
      page.h1_count || '',
      page.word_count || '',
      issue.severity || '',
      issue.issue_type || '',
      (issue.description || '').replace(/"/g, '""'),
      (issue.recommended_fix || '').replace(/"/g, '""')
    ].map(field => `"${field}"`).join(',');
  });

  return [headers.join(','), ...rows].join('\n');
}

export default router;
