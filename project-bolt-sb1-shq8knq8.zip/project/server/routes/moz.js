import express from 'express';
import { supabase } from '../config/supabase.js';
import { isMozEnabled } from '../config/features.js';
import { fetchMozMetrics } from '../services/mozService.js';

const router = express.Router();

router.post('/fetch/:websiteId', async (req, res) => {
  try {
    if (!isMozEnabled()) {
      return res.status(503).json({
        error: 'Moz integration disabled',
        message: 'Set ENABLE_MOZ=true and configure MOZ_ACCESS_ID and MOZ_SECRET_KEY to enable this feature'
      });
    }

    const { data: website, error: websiteError } = await supabase
      .from('websites')
      .select('domain')
      .eq('id', req.params.websiteId)
      .single();

    if (websiteError || !website) {
      return res.status(404).json({ error: 'Website not found' });
    }

    // Fetch metrics from Moz API
    console.log(`Fetching Moz metrics for ${website.domain}...`);
    const metrics = await fetchMozMetrics(website.domain);

    // Store in database
    const { data: mozData, error } = await supabase
      .from('moz_data')
      .insert({
        website_id: req.params.websiteId,
        domain_authority: metrics.domain_authority,
        page_authority: metrics.page_authority || null,
        spam_score: metrics.spam_score || null,
        linking_root_domains: metrics.linking_root_domains,
        total_links: metrics.total_links || null,
        last_crawled: metrics.last_crawled || new Date().toISOString(),
        data_source: metrics.source,
        fetched_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error) throw error;

    res.json(mozData);
  } catch (error) {
    console.error('Moz fetch error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

router.get('/data/:websiteId', async (req, res) => {
  try {
    const { data: mozData, error } = await supabase
      .from('moz_data')
      .select('*')
      .eq('website_id', req.params.websiteId)
      .order('fetched_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) throw error;

    res.json(mozData || null);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
