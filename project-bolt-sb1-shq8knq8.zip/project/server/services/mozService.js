import crypto from 'crypto';
import { isMozEnabled } from '../config/features.js';

/**
 * Moz API Service
 *
 * Integrates with Moz Links API to fetch:
 * - Domain Authority (DA)
 * - Spam Score
 * - Linking Root Domains
 *
 * API Documentation: https://moz.com/help/links-api
 */

const MOZ_API_BASE = 'https://lsapi.seomoz.com/v2';

/**
 * Generate Moz API authentication headers
 * Uses HMAC-SHA1 signature for authentication
 */
function generateAuthHeaders() {
  const accessId = process.env.MOZ_ACCESS_ID;
  const secretKey = process.env.MOZ_SECRET_KEY;

  if (!accessId || !secretKey) {
    throw new Error('Moz credentials not configured');
  }

  const expires = Math.floor(Date.now() / 1000) + 300; // 5 minutes from now
  const stringToSign = `${accessId}\n${expires}`;

  const signature = crypto
    .createHmac('sha1', secretKey)
    .update(stringToSign)
    .digest('base64');

  return {
    'Authorization': `Basic ${Buffer.from(`${accessId}:${signature}`).toString('base64')}`,
    'Content-Type': 'application/json'
  };
}

/**
 * Fetch Domain Authority and other metrics from Moz
 * @param {string} domain - The domain to analyze (e.g., 'example.com')
 * @returns {Promise<Object>} Moz metrics
 */
export async function fetchMozMetrics(domain) {
  if (!isMozEnabled()) {
    return getMockData(domain);
  }

  try {
    const headers = generateAuthHeaders();

    // Moz URL Metrics API endpoint
    const url = `${MOZ_API_BASE}/url_metrics`;

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        targets: [domain],
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Moz API Error:', response.status, errorText);

      // If quota exceeded or other error, return mock data
      if (response.status === 429 || response.status === 402) {
        console.warn('Moz API quota exceeded, returning mock data');
        return getMockData(domain);
      }

      throw new Error(`Moz API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();

    if (!data || !data.results || data.results.length === 0) {
      console.warn('No Moz data returned, using mock data');
      return getMockData(domain);
    }

    const result = data.results[0];

    return {
      domain_authority: Math.round(result.domain_authority || 0),
      page_authority: Math.round(result.page_authority || 0),
      spam_score: Math.round(result.spam_score || 0),
      linking_root_domains: result.external_pages || 0,
      total_links: result.external_links || 0,
      last_crawled: result.last_crawled || new Date().toISOString(),
      source: 'moz_api'
    };
  } catch (error) {
    console.error('Error fetching Moz metrics:', error.message);

    // Return mock data as fallback
    return getMockData(domain);
  }
}

/**
 * Get mock Moz data for testing or when API is disabled
 * @param {string} domain - The domain
 * @returns {Object} Mock Moz metrics
 */
function getMockData(domain) {
  // Generate semi-realistic mock data based on domain
  const hash = domain.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);

  return {
    domain_authority: 30 + (hash % 50),
    page_authority: 25 + (hash % 45),
    spam_score: hash % 15,
    linking_root_domains: 100 + (hash % 900),
    total_links: 1000 + (hash % 9000),
    last_crawled: new Date().toISOString(),
    source: 'mock_data'
  };
}

/**
 * Fetch link metrics (linking root domains, etc.)
 * @param {string} domain - The domain to analyze
 * @returns {Promise<Object>} Link metrics
 */
export async function fetchLinkMetrics(domain) {
  if (!isMozEnabled()) {
    return {
      linking_root_domains: 250,
      total_inbound_links: 1500,
      source: 'mock_data'
    };
  }

  try {
    const headers = generateAuthHeaders();

    const url = `${MOZ_API_BASE}/link_metrics`;

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        targets: [domain]
      })
    });

    if (!response.ok) {
      console.error('Moz Link Metrics Error:', response.status);
      return {
        linking_root_domains: 250,
        total_inbound_links: 1500,
        source: 'mock_data'
      };
    }

    const data = await response.json();
    const result = data.results?.[0];

    return {
      linking_root_domains: result?.root_domains_to_root_domain || 0,
      total_inbound_links: result?.external_links_to_root_domain || 0,
      source: 'moz_api'
    };
  } catch (error) {
    console.error('Error fetching Moz link metrics:', error.message);
    return {
      linking_root_domains: 250,
      total_inbound_links: 1500,
      source: 'mock_data'
    };
  }
}

/**
 * Check if Moz API is configured and working
 * @returns {Promise<boolean>}
 */
export async function testMozConnection() {
  if (!isMozEnabled()) {
    return false;
  }

  try {
    const metrics = await fetchMozMetrics('example.com');
    return metrics.source === 'moz_api';
  } catch (error) {
    console.error('Moz connection test failed:', error.message);
    return false;
  }
}

export default {
  fetchMozMetrics,
  fetchLinkMetrics,
  testMozConnection
};
