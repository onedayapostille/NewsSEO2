import { supabase } from '../config/supabase.js';
import { analyzePage } from './analyzer.js';
import { classifyPageType, normalizeUrl, isValidInternalUrl } from '../utils/url-utils.js';
import { fetchPage } from '../utils/http-client.js';

export async function startCrawl(sessionId, websiteId, crawlLimit) {
  try {
    await updateSessionStatus(sessionId, 'running');

    const { data: website } = await supabase
      .from('websites')
      .select('domain')
      .eq('id', websiteId)
      .single();

    const baseUrl = `https://${website.domain}`;

    const crawledUrls = new Set();
    const discoveredUrls = [];
    const pages = [];
    let pagesFailed = 0;

    discoveredUrls.push({ url: baseUrl, from: null, priority: 1 });

    while (crawledUrls.size < crawlLimit && discoveredUrls.length > 0) {
      discoveredUrls.sort((a, b) => a.priority - b.priority);
      const { url, from } = discoveredUrls.shift();

      if (crawledUrls.has(url)) continue;

      crawledUrls.add(url);

      try {
        const pageData = await fetchPage(url, baseUrl);

        const pageType = classifyPageType(url, pageData);

        const pageRecord = {
          crawl_session_id: sessionId,
          url: url,
          page_type: pageType,
          http_status: pageData.status,
          title: pageData.title || null,
          title_length: (pageData.title || '').length,
          meta_robots: pageData.metaRobots || null,
          x_robots_tag: pageData.xRobotsTag || null,
          canonical_url: pageData.canonicalUrl || null,
          canonical_status: pageData.canonicalStatus || null,
          h1_tags: JSON.stringify(pageData.h1Tags || []),
          h1_count: (pageData.h1Tags || []).length,
          word_count: pageData.wordCount || 0,
          has_video_embed: pageData.hasVideoEmbed || false,
          schema_types: JSON.stringify(pageData.schemaTypes || []),
          internal_links: JSON.stringify(pageData.internalLinks || []),
          discovered_from_url: from
        };

        const { data: savedPage } = await supabase
          .from('pages')
          .insert(pageRecord)
          .select()
          .single();

        pages.push(savedPage);

        const newUrls = smartUrlDiscovery(
          url,
          pageData.internalLinks || [],
          baseUrl,
          crawledUrls,
          pages,
          crawlLimit
        );

        newUrls.forEach(newUrl => {
          if (!crawledUrls.has(newUrl.url) && !discoveredUrls.some(d => d.url === newUrl.url)) {
            discoveredUrls.push(newUrl);
          }
        });

      } catch (error) {
        pagesFailed++;
        console.error(`Failed to crawl ${url}:`, error.message);

        await supabase.from('pages').insert({
          crawl_session_id: sessionId,
          url: url,
          crawl_error: error.message,
          http_status: error.status || 0,
          discovered_from_url: from
        });
      }
    }

    const issues = await analyzePage(pages, sessionId);

    const severityCounts = {
      critical: issues.filter(i => i.severity === 'critical').length,
      high: issues.filter(i => i.severity === 'high').length,
      medium: issues.filter(i => i.severity === 'medium').length,
      low: issues.filter(i => i.severity === 'low').length
    };

    await supabase
      .from('crawl_sessions')
      .update({
        status: 'completed',
        finished_at: new Date().toISOString(),
        pages_crawled: crawledUrls.size,
        pages_failed: pagesFailed,
        total_issues: issues.length,
        critical_issues: severityCounts.critical,
        high_issues: severityCounts.high,
        medium_issues: severityCounts.medium,
        low_issues: severityCounts.low
      })
      .eq('id', sessionId);

  } catch (error) {
    console.error('Crawl error:', error);
    await supabase
      .from('crawl_sessions')
      .update({
        status: 'failed',
        error_message: error.message,
        finished_at: new Date().toISOString()
      })
      .eq('id', sessionId);
  }
}

function smartUrlDiscovery(currentUrl, links, baseUrl, crawledUrls, pages, crawlLimit) {
  const discovered = [];
  const pageTypes = pages.map(p => p.page_type);

  const needsArticle = !pageTypes.includes('article') && pages.length < 5;
  const needsCategory = !pageTypes.includes('category');
  const needsPagination = !pageTypes.includes('pagination');
  const needsSearch = !pageTypes.includes('search');
  const needsSearchPagination = !pageTypes.includes('search_pagination');
  const needsTag = !pageTypes.includes('tag');
  const needsAmp = !pageTypes.includes('amp');

  for (const link of links) {
    if (crawledUrls.size + discovered.length >= crawlLimit) break;
    if (crawledUrls.has(link)) continue;

    const url = link.toLowerCase();

    if (needsArticle && (url.includes('/article/') || url.includes('/news/') || url.includes('/post/') || url.match(/\/\d{4}\/\d{2}\//))) {
      discovered.push({ url: link, from: currentUrl, priority: 2 });
      continue;
    }

    if (needsCategory && (url.includes('/category/') || url.includes('/section/') || url.includes('/topic/'))) {
      discovered.push({ url: link, from: currentUrl, priority: 3 });
      continue;
    }

    if (needsPagination && (url.includes('/page/2') || url.includes('?page=2') || url.includes('&page=2'))) {
      discovered.push({ url: link, from: currentUrl, priority: 4 });
      continue;
    }

    if (needsSearch && (url.includes('/search') || url.includes('?q=') || url.includes('?s='))) {
      discovered.push({ url: link, from: currentUrl, priority: 5 });
      continue;
    }

    if (needsSearchPagination && (url.includes('/search') || url.includes('?q=')) && (url.includes('page=') || url.includes('/page/'))) {
      discovered.push({ url: link, from: currentUrl, priority: 6 });
      continue;
    }

    if (needsTag && (url.includes('/tag/') || url.includes('/tags/'))) {
      discovered.push({ url: link, from: currentUrl, priority: 7 });
      continue;
    }

    if (needsAmp && (url.includes('/amp/') || url.includes('/amp') || url.includes('?amp=1'))) {
      discovered.push({ url: link, from: currentUrl, priority: 8 });
      continue;
    }

    if (discovered.length < crawlLimit - crawledUrls.size) {
      discovered.push({ url: link, from: currentUrl, priority: 9 });
    }
  }

  return discovered;
}

async function updateSessionStatus(sessionId, status) {
  await supabase
    .from('crawl_sessions')
    .update({ status })
    .eq('id', sessionId);
}
