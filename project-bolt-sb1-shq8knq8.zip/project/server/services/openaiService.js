import { isOpenAiEnabled } from '../config/features.js';

/**
 * OpenAI Service
 *
 * Provides AI-powered SEO recommendations and analysis using OpenAI's GPT models.
 * Features:
 * - Generate fix recommendations for SEO issues
 * - Create task lists for project management tools (ClickUp, Jira, etc.)
 * - Generate executive summaries of crawl results
 *
 * API Documentation: https://platform.openai.com/docs/api-reference
 */

const OPENAI_API_BASE = 'https://api.openai.com/v1';

/**
 * Call OpenAI API with retry logic
 * @param {string} endpoint - API endpoint
 * @param {Object} payload - Request payload
 * @returns {Promise<Object>} API response
 */
async function callOpenAI(endpoint, payload) {
  const apiKey = process.env.OPENAI_API_KEY;

  if (!apiKey) {
    throw new Error('OpenAI API key not configured');
  }

  const model = process.env.OPENAI_MODEL || 'gpt-3.5-turbo';

  const response = await fetch(`${OPENAI_API_BASE}${endpoint}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      ...payload,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`OpenAI API error: ${response.status} - ${error}`);
  }

  return await response.json();
}

/**
 * Generate SEO recommendations based on issues
 * @param {Array} issues - Array of SEO issues
 * @returns {Promise<Object>} Recommendations
 */
export async function generateRecommendations(issues) {
  if (!isOpenAiEnabled() || !issues || issues.length === 0) {
    return getRuleBasedRecommendations(issues);
  }

  try {
    const issuesSummary = issues.slice(0, 20).map(issue => ({
      type: issue.issue_type,
      severity: issue.severity,
      url: issue.url,
      details: issue.details
    }));

    const prompt = `You are an SEO expert. Analyze these SEO issues and provide actionable recommendations:

${JSON.stringify(issuesSummary, null, 2)}

For each type of issue, provide:
1. A clear explanation of why it's a problem
2. Specific step-by-step fix instructions
3. Expected impact on SEO
4. Priority level (Critical, High, Medium, Low)

Format your response as JSON with this structure:
{
  "recommendations": [
    {
      "issue_type": "string",
      "explanation": "string",
      "fix_steps": ["step1", "step2"],
      "impact": "string",
      "priority": "string"
    }
  ],
  "summary": "overall summary"
}`;

    const response = await callOpenAI('/chat/completions', {
      messages: [
        {
          role: 'system',
          content: 'You are an expert SEO consultant providing technical recommendations.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 2000,
    });

    const content = response.choices[0].message.content;

    try {
      return JSON.parse(content);
    } catch (parseError) {
      return {
        recommendations: [{
          issue_type: 'general',
          explanation: content,
          fix_steps: [],
          impact: 'Various',
          priority: 'Medium'
        }],
        summary: content
      };
    }
  } catch (error) {
    console.error('Error generating AI recommendations:', error.message);
    return getRuleBasedRecommendations(issues);
  }
}

/**
 * Generate task list for project management tools
 * @param {Array} issues - Array of SEO issues
 * @param {string} format - Output format ('clickup', 'jira', 'markdown')
 * @returns {Promise<Object>} Task list
 */
export async function generateTaskList(issues, format = 'clickup') {
  if (!isOpenAiEnabled()) {
    return getRuleBasedTasks(issues, format);
  }

  try {
    const issuesSummary = issues.slice(0, 15).map(issue => ({
      type: issue.issue_type,
      severity: issue.severity,
      url: issue.url
    }));

    const prompt = `Convert these SEO issues into actionable tasks for ${format}:

${JSON.stringify(issuesSummary, null, 2)}

Create tasks with:
- Clear, action-oriented titles
- Detailed descriptions with context
- Estimated effort (Small, Medium, Large)
- Priority (Urgent, High, Normal, Low)

Return JSON array of tasks:
[
  {
    "title": "string",
    "description": "string",
    "priority": "string",
    "effort": "string",
    "tags": ["tag1", "tag2"]
  }
]`;

    const response = await callOpenAI('/chat/completions', {
      messages: [
        {
          role: 'system',
          content: 'You are a technical project manager converting SEO issues into actionable development tasks.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.5,
      max_tokens: 1500,
    });

    const content = response.choices[0].message.content;

    try {
      const tasks = JSON.parse(content);
      return {
        format,
        tasks,
        total: tasks.length
      };
    } catch (parseError) {
      return getRuleBasedTasks(issues, format);
    }
  } catch (error) {
    console.error('Error generating task list:', error.message);
    return getRuleBasedTasks(issues, format);
  }
}

/**
 * Generate executive summary of crawl results
 * @param {Object} crawlData - Crawl session data with statistics
 * @returns {Promise<Object>} Executive summary
 */
export async function generateExecutiveSummary(crawlData) {
  if (!isOpenAiEnabled()) {
    return getRuleBasedSummary(crawlData);
  }

  try {
    const { total_pages, critical_issues, high_issues, medium_issues, low_issues } = crawlData;

    const prompt = `Create an executive summary for this SEO audit:

Pages Analyzed: ${total_pages}
Critical Issues: ${critical_issues}
High Priority Issues: ${high_issues}
Medium Priority Issues: ${medium_issues}
Low Priority Issues: ${low_issues}

Provide:
1. Overall health score (0-100)
2. Key findings (3-5 bullet points)
3. Top 3 priority actions
4. Business impact assessment
5. Recommended timeline for fixes

Keep it concise and business-focused. Return as JSON:
{
  "health_score": number,
  "health_status": "string",
  "key_findings": ["string"],
  "priority_actions": ["string"],
  "business_impact": "string",
  "timeline": "string"
}`;

    const response = await callOpenAI('/chat/completions', {
      messages: [
        {
          role: 'system',
          content: 'You are an SEO strategist presenting findings to business stakeholders.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.6,
      max_tokens: 1000,
    });

    const content = response.choices[0].message.content;

    try {
      return JSON.parse(content);
    } catch (parseError) {
      return getRuleBasedSummary(crawlData);
    }
  } catch (error) {
    console.error('Error generating summary:', error.message);
    return getRuleBasedSummary(crawlData);
  }
}

/**
 * Rule-based recommendations fallback
 */
function getRuleBasedRecommendations(issues) {
  const recommendations = {
    'missing_canonical': {
      explanation: 'Canonical tags help search engines understand which version of a page is the primary one.',
      fix_steps: [
        'Add canonical link tag to page head',
        'Ensure canonical points to the preferred URL',
        'Verify canonical is absolute URL'
      ],
      impact: 'Prevents duplicate content issues',
      priority: 'High'
    },
    'canonical_mismatch': {
      explanation: 'Canonical tag points to a different URL, which may cause indexing issues.',
      fix_steps: [
        'Review current canonical URL',
        'Update canonical to point to correct page',
        'Remove any conflicting canonicals'
      ],
      impact: 'Ensures correct page gets indexed',
      priority: 'Critical'
    },
    'missing_h1': {
      explanation: 'H1 tags are important for page structure and SEO.',
      fix_steps: [
        'Add one H1 tag to page',
        'Include primary keyword in H1',
        'Keep H1 descriptive and unique'
      ],
      impact: 'Improves page relevance signals',
      priority: 'Medium'
    }
  };

  const issueTypes = [...new Set(issues.map(i => i.issue_type))];

  return {
    recommendations: issueTypes.map(type => ({
      issue_type: type,
      ...recommendations[type] || {
        explanation: 'This issue may affect SEO performance',
        fix_steps: ['Review and fix the issue'],
        impact: 'Improves SEO',
        priority: 'Medium'
      }
    })),
    summary: `Found ${issues.length} issues across ${issueTypes.length} categories. Focus on critical and high priority items first.`,
    source: 'rule_based'
  };
}

/**
 * Rule-based task generation fallback
 */
function getRuleBasedTasks(issues, format) {
  const tasks = issues.slice(0, 10).map(issue => ({
    title: `Fix ${issue.issue_type.replace(/_/g, ' ')} on ${new URL(issue.url).pathname}`,
    description: issue.details || `Address ${issue.issue_type} issue found during SEO audit`,
    priority: issue.severity === 'critical' ? 'Urgent' : issue.severity === 'high' ? 'High' : 'Normal',
    effort: 'Small',
    tags: ['seo', issue.issue_type, issue.severity]
  }));

  return {
    format,
    tasks,
    total: tasks.length,
    source: 'rule_based'
  };
}

/**
 * Rule-based summary fallback
 */
function getRuleBasedSummary(crawlData) {
  const { total_pages = 0, critical_issues = 0, high_issues = 0, medium_issues = 0, low_issues = 0 } = crawlData;
  const totalIssues = critical_issues + high_issues + medium_issues + low_issues;
  const healthScore = Math.max(0, 100 - (critical_issues * 10 + high_issues * 5 + medium_issues * 2 + low_issues));

  return {
    health_score: Math.round(healthScore),
    health_status: healthScore >= 80 ? 'Good' : healthScore >= 60 ? 'Fair' : 'Needs Improvement',
    key_findings: [
      `Analyzed ${total_pages} pages`,
      `Found ${totalIssues} total issues`,
      `${critical_issues} critical issues require immediate attention`
    ],
    priority_actions: [
      'Fix all critical issues first',
      'Address high priority canonical and indexing issues',
      'Review and optimize content structure'
    ],
    business_impact: totalIssues > 50 ? 'Significant SEO issues may affect search rankings' : 'Minor issues, good overall SEO health',
    timeline: critical_issues > 0 ? '1-2 weeks for critical fixes' : '2-4 weeks for optimization',
    source: 'rule_based'
  };
}

export default {
  generateRecommendations,
  generateTaskList,
  generateExecutiveSummary
};
