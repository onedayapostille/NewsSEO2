import { supabase } from '../config/supabase.js';

export async function analyzePage(pages, sessionId) {
  const issues = [];

  for (const page of pages) {
    issues.push(...analyzeIndexing(page));
    issues.push(...analyzeCanonical(page));
    issues.push(...analyzeSearchPages(page));
    issues.push(...analyzeStructure(page));
    issues.push(...analyzeTechnical(page));
    issues.push(...analyzeAMP(page, pages));
  }

  issues.push(...analyzePagination(pages));
  issues.push(...analyzeSitewide(pages));

  for (const issue of issues) {
    await supabase.from('seo_issues').insert({
      crawl_session_id: sessionId,
      page_id: issue.page_id || null,
      issue_type: issue.issue_type,
      issue_subtype: issue.issue_subtype,
      severity: issue.severity,
      title: issue.title,
      description: issue.description,
      recommended_fix: issue.recommended_fix,
      evidence_json: JSON.stringify(issue.evidence || {}),
      url: issue.url
    });
  }

  return issues;
}

function analyzeIndexing(page) {
  const issues = [];
  const metaRobots = (page.meta_robots || '').toLowerCase();
  const isIndexable = !metaRobots.includes('noindex');

  if (page.page_type === 'search' && isIndexable) {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'indexing',
      issue_subtype: 'search_indexable',
      severity: 'critical',
      title: 'Search page is indexable',
      description: 'Search result pages should not be indexed by search engines as they create duplicate content and waste crawl budget.',
      recommended_fix: 'Add <meta name="robots" content="noindex,follow"> to all search result pages.',
      evidence: { meta_robots: page.meta_robots, page_type: page.page_type }
    });
  }

  if (page.page_type === 'search_pagination' && isIndexable) {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'indexing',
      issue_subtype: 'search_pagination_indexable',
      severity: 'critical',
      title: 'Search pagination is indexable',
      description: 'Paginated search results should not be indexed as they create unlimited URL variations.',
      recommended_fix: 'Add <meta name="robots" content="noindex,follow"> to all search pagination pages.',
      evidence: { meta_robots: page.meta_robots, page_type: page.page_type }
    });
  }

  if (page.page_type === 'tag' && isIndexable) {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'indexing',
      issue_subtype: 'tag_indexable',
      severity: 'medium',
      title: 'Tag page is indexable',
      description: 'Tag pages can create thin content and duplicate content issues. Consider noindexing unless they provide unique value.',
      recommended_fix: 'Evaluate if tag pages provide unique content. If not, add <meta name="robots" content="noindex,follow">.',
      evidence: { meta_robots: page.meta_robots, page_type: page.page_type }
    });
  }

  if (page.word_count < 100 && !page.has_video_embed && isIndexable && page.page_type !== 'pagination') {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'indexing',
      issue_subtype: 'thin_content_indexable',
      severity: 'high',
      title: 'Thin content page is indexable',
      description: `This page has only ${page.word_count} words and no video content. Thin pages can harm overall site quality.`,
      recommended_fix: 'Either add more substantial content or noindex this page with <meta name="robots" content="noindex,follow">.',
      evidence: { word_count: page.word_count, has_video: page.has_video_embed }
    });
  }

  if (metaRobots.includes('noindex') && metaRobots.includes('nofollow')) {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'indexing',
      issue_subtype: 'noindex_nofollow',
      severity: 'medium',
      title: 'Page uses noindex,nofollow',
      description: 'Using nofollow prevents search engines from discovering linked content. For most cases, noindex,follow is preferred.',
      recommended_fix: 'Change to <meta name="robots" content="noindex,follow"> unless you specifically want to prevent link discovery.',
      evidence: { meta_robots: page.meta_robots }
    });
  }

  return issues;
}

function analyzeCanonical(page) {
  const issues = [];
  const metaRobots = (page.meta_robots || '').toLowerCase();
  const isIndexable = !metaRobots.includes('noindex');

  if (isIndexable && !page.canonical_url && page.page_type !== 'pagination') {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'canonical',
      issue_subtype: 'missing_canonical',
      severity: 'high',
      title: 'Missing canonical tag',
      description: 'Indexable pages should have a self-referencing canonical tag to prevent duplicate content issues.',
      recommended_fix: `Add <link rel="canonical" href="${page.url}"> to the page head.`,
      evidence: { has_canonical: false, is_indexable: isIndexable }
    });
  }

  if (page.canonical_url && page.canonical_status && page.canonical_status !== 200) {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'canonical',
      issue_subtype: 'canonical_not_200',
      severity: 'critical',
      title: `Canonical URL returns ${page.canonical_status}`,
      description: 'The canonical URL must return a 200 status code. Search engines may ignore canonicals pointing to non-200 pages.',
      recommended_fix: page.canonical_status === 404
        ? 'Update the canonical to point to an existing page or use a self-referencing canonical.'
        : 'Ensure the canonical URL returns a 200 status code without redirects.',
      evidence: { canonical_url: page.canonical_url, canonical_status: page.canonical_status }
    });
  }

  if (page.canonical_url && page.canonical_url !== page.url && page.page_type === 'article') {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'canonical',
      issue_subtype: 'non_self_referencing',
      severity: 'high',
      title: 'Article canonical points elsewhere',
      description: 'Article pages should typically have self-referencing canonical tags unless this is genuinely duplicate content.',
      recommended_fix: 'Verify if this is intentional. If not, update canonical to point to itself.',
      evidence: { page_url: page.url, canonical_url: page.canonical_url }
    });
  }

  if (metaRobots.includes('noindex') && page.canonical_url) {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'canonical',
      issue_subtype: 'noindex_with_canonical',
      severity: 'medium',
      title: 'Page has both noindex and canonical',
      description: 'Using noindex and canonical together sends conflicting signals. Noindex tells engines not to index, while canonical suggests another URL to index.',
      recommended_fix: 'Remove the canonical tag from noindexed pages, or remove noindex if the page should be indexed.',
      evidence: { meta_robots: page.meta_robots, canonical_url: page.canonical_url }
    });
  }

  return issues;
}

function analyzePagination(pages) {
  const issues = [];
  const paginationPages = pages.filter(p => p.page_type === 'pagination');

  for (const page of paginationPages) {
    const pageNum = extractPageNumber(page.url);

    if (pageNum > 1 && page.canonical_url) {
      const canonicalPageNum = extractPageNumber(page.canonical_url);

      if (canonicalPageNum === 1 || canonicalPageNum === 0) {
        issues.push({
          page_id: page.id,
          url: page.url,
          issue_type: 'pagination',
          issue_subtype: 'incorrect_pagination_canonical',
          severity: 'critical',
          title: 'Pagination page canonicals to page 1',
          description: `Page ${pageNum} of pagination should canonical to itself, not to page 1. Canonicalizing to page 1 prevents the other pages from being indexed.`,
          recommended_fix: `Change canonical to point to itself: ${page.url}`,
          evidence: { page_number: pageNum, current_canonical: page.canonical_url }
        });
      }
    }

    const metaRobots = (page.meta_robots || '').toLowerCase();
    if (metaRobots.includes('noindex')) {
      issues.push({
        page_id: page.id,
        url: page.url,
        issue_type: 'pagination',
        issue_subtype: 'pagination_noindexed',
        severity: 'high',
        title: 'Pagination page is noindexed',
        description: 'Pagination pages should be indexable with self-referencing canonicals to ensure all content is discoverable.',
        recommended_fix: 'Remove noindex directive and add self-referencing canonical tag.',
        evidence: { meta_robots: page.meta_robots }
      });
    }

    if (!page.canonical_url) {
      issues.push({
        page_id: page.id,
        url: page.url,
        issue_type: 'pagination',
        issue_subtype: 'pagination_missing_canonical',
        severity: 'high',
        title: 'Pagination page missing canonical',
        description: 'Pagination pages should have self-referencing canonical tags.',
        recommended_fix: `Add <link rel="canonical" href="${page.url}">`,
        evidence: { has_canonical: false }
      });
    }
  }

  return issues;
}

function analyzeSearchPages(page) {
  const issues = [];

  if ((page.page_type === 'search' || page.page_type === 'search_pagination') && page.http_status === 404) {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'search',
      issue_subtype: 'search_returns_404',
      severity: 'critical',
      title: 'Search page returns 404',
      description: 'Old search URLs returning 404 after a site migration or redesign can cause crawl errors and poor user experience.',
      recommended_fix: 'Implement 301 redirects to the new search format, or return 410 Gone if search functionality was intentionally removed.',
      evidence: { http_status: page.http_status, page_type: page.page_type }
    });
  }

  return issues;
}

function analyzeStructure(page) {
  const issues = [];

  if (page.h1_count > 1) {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'structure',
      issue_subtype: 'multiple_h1',
      severity: 'medium',
      title: 'Multiple H1 tags detected',
      description: `This page has ${page.h1_count} H1 tags. While not strictly wrong, a single H1 is best practice for clarity and SEO.`,
      recommended_fix: 'Use only one H1 tag per page, typically for the main heading. Use H2-H6 for subheadings.',
      evidence: { h1_count: page.h1_count, h1_tags: page.h1_tags }
    });
  }

  if (page.h1_count === 0 && page.page_type === 'article') {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'structure',
      issue_subtype: 'missing_h1',
      severity: 'high',
      title: 'Missing H1 tag',
      description: 'This article page has no H1 tag. H1 tags are important for content hierarchy and SEO.',
      recommended_fix: 'Add an H1 tag containing the main article headline.',
      evidence: { h1_count: 0 }
    });
  }

  if (page.word_count < 300 && page.page_type === 'article' && !page.has_video_embed) {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'structure',
      issue_subtype: 'thin_content',
      severity: 'medium',
      title: 'Thin content detected',
      description: `This article has only ${page.word_count} words. Articles under 300 words may be considered thin content.`,
      recommended_fix: 'Expand the article with more detailed, valuable content or consolidate with related articles.',
      evidence: { word_count: page.word_count, has_video: false }
    });
  }

  if (!page.title || page.title.trim() === '') {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'structure',
      issue_subtype: 'missing_title',
      severity: 'critical',
      title: 'Missing title tag',
      description: 'This page has no title tag. Title tags are critical for SEO and user experience.',
      recommended_fix: 'Add a descriptive, unique title tag between 30-60 characters.',
      evidence: { has_title: false }
    });
  }

  if (page.title && (page.title_length < 30 || page.title_length > 60)) {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'structure',
      issue_subtype: 'title_length',
      severity: 'low',
      title: page.title_length < 30 ? 'Title tag too short' : 'Title tag too long',
      description: `Title is ${page.title_length} characters. Optimal length is 30-60 characters. ${page.title_length > 60 ? 'Long titles may be truncated in search results.' : 'Short titles may not be descriptive enough.'}`,
      recommended_fix: page.title_length < 30
        ? 'Expand the title to be more descriptive.'
        : 'Shorten the title to fit within 60 characters while keeping key information.',
      evidence: { title: page.title, title_length: page.title_length }
    });
  }

  const schemaTypes = JSON.parse(page.schema_types || '[]');
  if (page.page_type === 'article' && !schemaTypes.includes('Article') && !schemaTypes.includes('NewsArticle')) {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'structure',
      issue_subtype: 'missing_schema',
      severity: 'medium',
      title: 'Missing Article schema',
      description: 'This article page is missing Article or NewsArticle structured data. Schema markup helps search engines understand your content.',
      recommended_fix: 'Add Article or NewsArticle schema.org structured data including headline, datePublished, author, and image properties.',
      evidence: { schema_types: schemaTypes }
    });
  }

  return issues;
}

function analyzeTechnical(page) {
  const issues = [];

  if (page.http_status >= 400 && page.http_status < 500) {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'technical',
      issue_subtype: 'http_error',
      severity: page.http_status === 404 ? 'high' : 'critical',
      title: `HTTP ${page.http_status} error`,
      description: `This page returns a ${page.http_status} status code but was found through internal linking.`,
      recommended_fix: page.http_status === 404
        ? 'Remove the link pointing to this page or implement a 301 redirect to a relevant page.'
        : 'Fix the server error or remove the link.',
      evidence: { http_status: page.http_status }
    });
  }

  if (page.http_status >= 500) {
    issues.push({
      page_id: page.id,
      url: page.url,
      issue_type: 'technical',
      issue_subtype: 'server_error',
      severity: 'critical',
      title: `Server error ${page.http_status}`,
      description: 'This page is returning a server error. This prevents indexing and harms user experience.',
      recommended_fix: 'Investigate and fix the server error immediately.',
      evidence: { http_status: page.http_status }
    });
  }

  const metaRobots = (page.meta_robots || '').toLowerCase();
  const xRobotsTag = (page.x_robots_tag || '').toLowerCase();

  if (metaRobots && xRobotsTag && metaRobots !== xRobotsTag) {
    const metaHasNoindex = metaRobots.includes('noindex');
    const xRobotsHasNoindex = xRobotsTag.includes('noindex');

    if (metaHasNoindex !== xRobotsHasNoindex) {
      issues.push({
        page_id: page.id,
        url: page.url,
        issue_type: 'technical',
        issue_subtype: 'conflicting_robots',
        severity: 'high',
        title: 'Conflicting robots directives',
        description: 'The meta robots tag and X-Robots-Tag header contain conflicting directives.',
        recommended_fix: 'Ensure both directives match, or remove one to avoid confusion.',
        evidence: { meta_robots: page.meta_robots, x_robots_tag: page.x_robots_tag }
      });
    }
  }

  return issues;
}

function analyzeAMP(page, allPages) {
  const issues = [];

  if (page.page_type === 'amp') {
    if (!page.canonical_url) {
      issues.push({
        page_id: page.id,
        url: page.url,
        issue_type: 'amp',
        issue_subtype: 'amp_missing_canonical',
        severity: 'critical',
        title: 'AMP page missing canonical',
        description: 'AMP pages must have a canonical tag pointing to the non-AMP version.',
        recommended_fix: 'Add a canonical tag pointing to the main non-AMP URL.',
        evidence: { has_canonical: false }
      });
    } else if (page.canonical_url.includes('/amp')) {
      issues.push({
        page_id: page.id,
        url: page.url,
        issue_type: 'amp',
        issue_subtype: 'amp_self_canonical',
        severity: 'high',
        title: 'AMP page has self-referencing canonical',
        description: 'AMP pages should canonical to the non-AMP version, not to themselves.',
        recommended_fix: 'Update the canonical to point to the non-AMP URL.',
        evidence: { canonical_url: page.canonical_url }
      });
    }
  }

  return issues;
}

function analyzeSitewide(pages) {
  const issues = [];

  const h1Map = new Map();
  for (const page of pages) {
    const h1Tags = JSON.parse(page.h1_tags || '[]');
    if (h1Tags.length > 0) {
      const h1 = h1Tags[0];
      if (!h1Map.has(h1)) {
        h1Map.set(h1, []);
      }
      h1Map.get(h1).push(page.url);
    }
  }

  for (const [h1, urls] of h1Map.entries()) {
    if (urls.length > 2) {
      issues.push({
        page_id: null,
        url: null,
        issue_type: 'structure',
        issue_subtype: 'duplicate_h1',
        severity: 'medium',
        title: 'Duplicate H1 across multiple pages',
        description: `The H1 "${h1}" appears on ${urls.length} pages, suggesting a template issue or lack of unique headings.`,
        recommended_fix: 'Ensure each page has a unique H1 that accurately describes its content.',
        evidence: { h1_text: h1, affected_urls: urls, count: urls.length }
      });
    }
  }

  const titleMap = new Map();
  for (const page of pages) {
    if (page.title) {
      if (!titleMap.has(page.title)) {
        titleMap.set(page.title, []);
      }
      titleMap.get(page.title).push(page.url);
    }
  }

  for (const [title, urls] of titleMap.entries()) {
    if (urls.length > 1) {
      issues.push({
        page_id: null,
        url: null,
        issue_type: 'structure',
        issue_subtype: 'duplicate_title',
        severity: 'high',
        title: 'Duplicate title tags',
        description: `The title "${title}" appears on ${urls.length} pages. Each page should have a unique title.`,
        recommended_fix: 'Create unique, descriptive titles for each page.',
        evidence: { title_text: title, affected_urls: urls, count: urls.length }
      });
    }
  }

  return issues;
}

function extractPageNumber(url) {
  const pageMatch = url.match(/[?&]page=(\d+)/i) || url.match(/\/page\/(\d+)/i);
  return pageMatch ? parseInt(pageMatch[1]) : 1;
}
