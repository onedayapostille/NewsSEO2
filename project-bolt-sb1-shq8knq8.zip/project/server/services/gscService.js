import { isGscEnabled } from '../config/features.js';
import { supabase } from '../config/supabase.js';

/**
 * Google Search Console Service
 *
 * Integrates with Google Search Console API to fetch:
 * - Coverage data (indexed vs excluded pages)
 * - Top performing pages
 * - Top search queries
 * - Click and impression data
 *
 * API Documentation: https://developers.google.com/webmaster-tools/search-console-api-original
 */

const GSC_API_BASE = 'https://www.googleapis.com/webmasters/v3';
const TOKEN_URL = 'https://oauth2.googleapis.com/token';

/**
 * Exchange authorization code for access token
 * @param {string} code - Authorization code from OAuth callback
 * @returns {Promise<Object>} Token response with access_token and refresh_token
 */
export async function exchangeCodeForToken(code) {
  const clientId = process.env.GSC_CLIENT_ID;
  const clientSecret = process.env.GSC_CLIENT_SECRET;
  const redirectUri = process.env.GSC_REDIRECT_URI;

  const response = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      code,
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: redirectUri,
      grant_type: 'authorization_code',
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Failed to exchange code for token: ${error}`);
  }

  return await response.json();
}

/**
 * Refresh access token using refresh token
 * @param {string} refreshToken - Refresh token
 * @returns {Promise<string>} New access token
 */
export async function refreshAccessToken(refreshToken) {
  const clientId = process.env.GSC_CLIENT_ID;
  const clientSecret = process.env.GSC_CLIENT_SECRET;

  const response = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      refresh_token: refreshToken,
      client_id: clientId,
      client_secret: clientSecret,
      grant_type: 'refresh_token',
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Failed to refresh token: ${error}`);
  }

  const data = await response.json();
  return data.access_token;
}

/**
 * Get access token for a website (refresh if needed)
 * @param {string} websiteId - Website ID
 * @returns {Promise<string>} Valid access token
 */
async function getAccessToken(websiteId) {
  const { data: website, error } = await supabase
    .from('websites')
    .select('gsc_access_token, gsc_refresh_token, gsc_token_expires_at')
    .eq('id', websiteId)
    .single();

  if (error || !website) {
    throw new Error('Website not found or GSC not connected');
  }

  // Check if token is expired or about to expire (within 5 minutes)
  const expiresAt = new Date(website.gsc_token_expires_at);
  const now = new Date();
  const fiveMinutesFromNow = new Date(now.getTime() + 5 * 60 * 1000);

  if (expiresAt > fiveMinutesFromNow && website.gsc_access_token) {
    return website.gsc_access_token;
  }

  // Refresh token
  console.log('Refreshing GSC access token...');
  const newAccessToken = await refreshAccessToken(website.gsc_refresh_token);

  // Update token in database
  await supabase
    .from('websites')
    .update({
      gsc_access_token: newAccessToken,
      gsc_token_expires_at: new Date(now.getTime() + 3600 * 1000).toISOString(), // 1 hour
    })
    .eq('id', websiteId);

  return newAccessToken;
}

/**
 * Fetch search analytics data (queries and pages)
 * @param {string} websiteId - Website ID
 * @param {string} siteUrl - Site URL (e.g., 'https://example.com/')
 * @param {Object} options - Query options
 * @returns {Promise<Object>} Search analytics data
 */
export async function fetchSearchAnalytics(websiteId, siteUrl, options = {}) {
  if (!isGscEnabled()) {
    return getMockSearchData();
  }

  try {
    const accessToken = await getAccessToken(websiteId);

    const {
      startDate = getDateDaysAgo(30),
      endDate = getDateDaysAgo(1),
      dimensions = ['page'],
      rowLimit = 10,
    } = options;

    const response = await fetch(
      `${GSC_API_BASE}/sites/${encodeURIComponent(siteUrl)}/searchAnalytics/query`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          startDate,
          endDate,
          dimensions,
          rowLimit,
        }),
      }
    );

    if (!response.ok) {
      const error = await response.text();
      console.error('GSC API Error:', response.status, error);
      return getMockSearchData();
    }

    const data = await response.json();
    return data.rows || [];
  } catch (error) {
    console.error('Error fetching GSC search analytics:', error.message);
    return getMockSearchData();
  }
}

/**
 * Fetch coverage data (indexed vs excluded pages)
 * @param {string} websiteId - Website ID
 * @param {string} siteUrl - Site URL
 * @returns {Promise<Object>} Coverage summary
 */
export async function fetchCoverageData(websiteId, siteUrl) {
  if (!isGscEnabled()) {
    return getMockCoverageData();
  }

  try {
    const accessToken = await getAccessToken(websiteId);

    // Fetch index coverage report
    const response = await fetch(
      `${GSC_API_BASE}/sites/${encodeURIComponent(siteUrl)}/urlCrawlErrorsCounts/query`,
      {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
      }
    );

    if (!response.ok) {
      console.warn('GSC coverage API not available, using search analytics as proxy');
      return getMockCoverageData();
    }

    const data = await response.json();

    return {
      indexed_pages: data.countPerTypes?.[0]?.entries?.reduce((sum, e) => sum + e.count, 0) || 0,
      excluded_pages: data.countPerTypes?.[1]?.entries?.reduce((sum, e) => sum + e.count, 0) || 0,
      errors: data.countPerTypes?.[2]?.entries?.reduce((sum, e) => sum + e.count, 0) || 0,
      last_updated: new Date().toISOString(),
      source: 'gsc_api',
    };
  } catch (error) {
    console.error('Error fetching GSC coverage data:', error.message);
    return getMockCoverageData();
  }
}

/**
 * Fetch top pages by clicks
 * @param {string} websiteId - Website ID
 * @param {string} siteUrl - Site URL
 * @returns {Promise<Array>} Top pages
 */
export async function fetchTopPages(websiteId, siteUrl) {
  const data = await fetchSearchAnalytics(websiteId, siteUrl, {
    dimensions: ['page'],
    rowLimit: 10,
  });

  if (Array.isArray(data)) {
    return data.map(row => ({
      url: row.keys[0],
      clicks: row.clicks,
      impressions: row.impressions,
      ctr: row.ctr,
      position: row.position,
    }));
  }

  return data;
}

/**
 * Fetch top queries
 * @param {string} websiteId - Website ID
 * @param {string} siteUrl - Site URL
 * @returns {Promise<Array>} Top queries
 */
export async function fetchTopQueries(websiteId, siteUrl) {
  const data = await fetchSearchAnalytics(websiteId, siteUrl, {
    dimensions: ['query'],
    rowLimit: 10,
  });

  if (Array.isArray(data)) {
    return data.map(row => ({
      query: row.keys[0],
      clicks: row.clicks,
      impressions: row.impressions,
      ctr: row.ctr,
      position: row.position,
    }));
  }

  return data;
}

/**
 * Get mock search analytics data
 * @returns {Array} Mock search data
 */
function getMockSearchData() {
  return [
    { keys: ['https://example.com/article-1'], clicks: 150, impressions: 2000, ctr: 0.075, position: 5.2 },
    { keys: ['https://example.com/article-2'], clicks: 120, impressions: 1800, ctr: 0.067, position: 6.1 },
    { keys: ['https://example.com/article-3'], clicks: 95, impressions: 1500, ctr: 0.063, position: 7.3 },
  ];
}

/**
 * Get mock coverage data
 * @returns {Object} Mock coverage data
 */
function getMockCoverageData() {
  return {
    indexed_pages: 150,
    excluded_pages: 25,
    errors: 3,
    last_updated: new Date().toISOString(),
    source: 'mock_data',
  };
}

/**
 * Get date N days ago in YYYY-MM-DD format
 * @param {number} days - Number of days ago
 * @returns {string} Date string
 */
function getDateDaysAgo(days) {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return date.toISOString().split('T')[0];
}

export default {
  exchangeCodeForToken,
  refreshAccessToken,
  fetchSearchAnalytics,
  fetchCoverageData,
  fetchTopPages,
  fetchTopQueries,
};
