/*
  # SEO Analysis Tool Database Schema

  ## Overview
  This migration creates the complete database schema for a news-focused SEO analysis tool.
  The schema supports multiple websites, historical crawl tracking, detailed page analysis,
  and comprehensive issue reporting.

  ## Tables Created

  ### 1. websites
  Stores information about websites being analyzed
  - `id` (uuid, primary key) - Unique website identifier
  - `domain` (text, unique) - Website domain (e.g., "example.com")
  - `display_name` (text) - Human-readable name for the website
  - `site_type` (text) - Type of site (default: "news")
  - `gsc_connected` (boolean) - Whether Google Search Console is connected
  - `gsc_property_url` (text, nullable) - GSC property URL
  - `gsc_refresh_token` (text, nullable) - Encrypted GSC OAuth refresh token
  - `created_at` (timestamptz) - When the website was added

  ### 2. crawl_sessions
  Tracks individual crawl sessions for each website
  - `id` (uuid, primary key) - Unique session identifier
  - `website_id` (uuid, foreign key) - Links to websites table
  - `started_at` (timestamptz) - When the crawl started
  - `finished_at` (timestamptz, nullable) - When the crawl completed
  - `crawl_limit` (integer) - Maximum pages to crawl (default: 10)
  - `status` (text) - Current status: queued, running, completed, failed
  - `error_message` (text, nullable) - Error details if failed
  - `pages_crawled` (integer) - Number of pages successfully crawled
  - `pages_failed` (integer) - Number of pages that failed
  - `total_issues` (integer) - Total issues found
  - `critical_issues` (integer) - Count of critical severity issues
  - `high_issues` (integer) - Count of high severity issues
  - `medium_issues` (integer) - Count of medium severity issues
  - `low_issues` (integer) - Count of low severity issues

  ### 3. pages
  Stores detailed information about each crawled page
  - `id` (uuid, primary key) - Unique page identifier
  - `crawl_session_id` (uuid, foreign key) - Links to crawl_sessions table
  - `url` (text) - Full URL of the page
  - `page_type` (text) - Classification: article, category, pagination, search, search_pagination, tag, amp, unknown
  - `http_status` (integer) - HTTP response status code
  - `title` (text, nullable) - Page title tag content
  - `title_length` (integer) - Length of title in characters
  - `meta_robots` (text, nullable) - Meta robots tag content
  - `x_robots_tag` (text, nullable) - X-Robots-Tag header value
  - `canonical_url` (text, nullable) - Canonical URL specified on the page
  - `canonical_status` (integer, nullable) - HTTP status of canonical URL
  - `h1_tags` (jsonb) - Array of H1 tag contents
  - `h1_count` (integer) - Number of H1 tags found
  - `word_count` (integer) - Estimated word count
  - `has_video_embed` (boolean) - Whether page contains video embeds
  - `schema_types` (jsonb) - Array of detected schema.org types
  - `internal_links` (jsonb) - Array of internal links discovered
  - `discovered_from_url` (text, nullable) - URL that linked to this page
  - `crawl_error` (text, nullable) - Error message if crawl failed
  - `created_at` (timestamptz) - When the page was crawled

  ### 4. seo_issues
  Records specific SEO issues found during analysis
  - `id` (uuid, primary key) - Unique issue identifier
  - `crawl_session_id` (uuid, foreign key) - Links to crawl_sessions table
  - `page_id` (uuid, foreign key, nullable) - Links to pages table (null for sitewide issues)
  - `issue_type` (text) - Category: canonical, pagination, indexing, amp, structure, technical
  - `issue_subtype` (text) - Specific issue identifier
  - `severity` (text) - Impact level: critical, high, medium, low
  - `title` (text) - Short issue title
  - `description` (text) - Detailed explanation of the issue
  - `recommended_fix` (text) - Actionable steps to resolve
  - `evidence_json` (jsonb) - Supporting data and examples
  - `url` (text, nullable) - Affected URL (denormalized for easier querying)
  - `created_at` (timestamptz) - When the issue was detected

  ### 5. gsc_data
  Stores Google Search Console data snapshots
  - `id` (uuid, primary key) - Unique record identifier
  - `website_id` (uuid, foreign key) - Links to websites table
  - `crawl_session_id` (uuid, foreign key, nullable) - Optional link to specific session
  - `indexed_pages` (integer) - Number of pages indexed by Google
  - `excluded_pages` (integer) - Number of pages excluded from index
  - `coverage_issues` (jsonb) - Array of coverage issues from GSC
  - `fetched_at` (timestamptz) - When the data was retrieved
  - `created_at` (timestamptz) - Record creation timestamp

  ### 6. moz_data
  Stores Moz API data for domain metrics
  - `id` (uuid, primary key) - Unique record identifier
  - `website_id` (uuid, foreign key) - Links to websites table
  - `domain_authority` (integer) - Moz Domain Authority score
  - `linking_root_domains` (integer) - Number of linking root domains
  - `fetched_at` (timestamptz) - When the data was retrieved
  - `created_at` (timestamptz) - Record creation timestamp

  ## Security
  - Row Level Security (RLS) is enabled on all tables
  - Since this is an internal tool without authentication, all tables allow public access
  - In future, policies can be added to restrict access by user

  ## Indexes
  Performance indexes are created for:
  - Foreign key relationships
  - Frequently filtered columns (status, severity, page_type)
  - Timestamp columns for historical queries
*/

-- Create websites table
CREATE TABLE IF NOT EXISTS websites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain text UNIQUE NOT NULL,
  display_name text NOT NULL,
  site_type text DEFAULT 'news',
  gsc_connected boolean DEFAULT false,
  gsc_property_url text,
  gsc_refresh_token text,
  created_at timestamptz DEFAULT now()
);

-- Create crawl_sessions table
CREATE TABLE IF NOT EXISTS crawl_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  website_id uuid NOT NULL REFERENCES websites(id) ON DELETE CASCADE,
  started_at timestamptz DEFAULT now(),
  finished_at timestamptz,
  crawl_limit integer DEFAULT 10,
  status text DEFAULT 'queued',
  error_message text,
  pages_crawled integer DEFAULT 0,
  pages_failed integer DEFAULT 0,
  total_issues integer DEFAULT 0,
  critical_issues integer DEFAULT 0,
  high_issues integer DEFAULT 0,
  medium_issues integer DEFAULT 0,
  low_issues integer DEFAULT 0
);

-- Create pages table
CREATE TABLE IF NOT EXISTS pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  crawl_session_id uuid NOT NULL REFERENCES crawl_sessions(id) ON DELETE CASCADE,
  url text NOT NULL,
  page_type text DEFAULT 'unknown',
  http_status integer,
  title text,
  title_length integer DEFAULT 0,
  meta_robots text,
  x_robots_tag text,
  canonical_url text,
  canonical_status integer,
  h1_tags jsonb DEFAULT '[]'::jsonb,
  h1_count integer DEFAULT 0,
  word_count integer DEFAULT 0,
  has_video_embed boolean DEFAULT false,
  schema_types jsonb DEFAULT '[]'::jsonb,
  internal_links jsonb DEFAULT '[]'::jsonb,
  discovered_from_url text,
  crawl_error text,
  created_at timestamptz DEFAULT now()
);

-- Create seo_issues table
CREATE TABLE IF NOT EXISTS seo_issues (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  crawl_session_id uuid NOT NULL REFERENCES crawl_sessions(id) ON DELETE CASCADE,
  page_id uuid REFERENCES pages(id) ON DELETE CASCADE,
  issue_type text NOT NULL,
  issue_subtype text NOT NULL,
  severity text NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  recommended_fix text NOT NULL,
  evidence_json jsonb DEFAULT '{}'::jsonb,
  url text,
  created_at timestamptz DEFAULT now()
);

-- Create gsc_data table
CREATE TABLE IF NOT EXISTS gsc_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  website_id uuid NOT NULL REFERENCES websites(id) ON DELETE CASCADE,
  crawl_session_id uuid REFERENCES crawl_sessions(id) ON DELETE SET NULL,
  indexed_pages integer DEFAULT 0,
  excluded_pages integer DEFAULT 0,
  coverage_issues jsonb DEFAULT '[]'::jsonb,
  fetched_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Create moz_data table
CREATE TABLE IF NOT EXISTS moz_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  website_id uuid NOT NULL REFERENCES websites(id) ON DELETE CASCADE,
  domain_authority integer,
  linking_root_domains integer,
  fetched_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_crawl_sessions_website_id ON crawl_sessions(website_id);
CREATE INDEX IF NOT EXISTS idx_crawl_sessions_status ON crawl_sessions(status);
CREATE INDEX IF NOT EXISTS idx_crawl_sessions_started_at ON crawl_sessions(started_at DESC);

CREATE INDEX IF NOT EXISTS idx_pages_crawl_session_id ON pages(crawl_session_id);
CREATE INDEX IF NOT EXISTS idx_pages_page_type ON pages(page_type);
CREATE INDEX IF NOT EXISTS idx_pages_http_status ON pages(http_status);
CREATE INDEX IF NOT EXISTS idx_pages_url ON pages(url);

CREATE INDEX IF NOT EXISTS idx_seo_issues_crawl_session_id ON seo_issues(crawl_session_id);
CREATE INDEX IF NOT EXISTS idx_seo_issues_page_id ON seo_issues(page_id);
CREATE INDEX IF NOT EXISTS idx_seo_issues_severity ON seo_issues(severity);
CREATE INDEX IF NOT EXISTS idx_seo_issues_issue_type ON seo_issues(issue_type);

CREATE INDEX IF NOT EXISTS idx_gsc_data_website_id ON gsc_data(website_id);
CREATE INDEX IF NOT EXISTS idx_gsc_data_fetched_at ON gsc_data(fetched_at DESC);

CREATE INDEX IF NOT EXISTS idx_moz_data_website_id ON moz_data(website_id);
CREATE INDEX IF NOT EXISTS idx_moz_data_fetched_at ON moz_data(fetched_at DESC);

-- Enable Row Level Security
ALTER TABLE websites ENABLE ROW LEVEL SECURITY;
ALTER TABLE crawl_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE seo_issues ENABLE ROW LEVEL SECURITY;
ALTER TABLE gsc_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE moz_data ENABLE ROW LEVEL SECURITY;

-- Create permissive policies for internal tool (no auth required)
-- In production with auth, these would check user permissions

CREATE POLICY "Allow all operations on websites"
  ON websites FOR ALL
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all operations on crawl_sessions"
  ON crawl_sessions FOR ALL
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all operations on pages"
  ON pages FOR ALL
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all operations on seo_issues"
  ON seo_issues FOR ALL
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all operations on gsc_data"
  ON gsc_data FOR ALL
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all operations on moz_data"
  ON moz_data FOR ALL
  USING (true)
  WITH CHECK (true);