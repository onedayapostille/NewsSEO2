export interface Website {
  id: string;
  domain: string;
  display_name: string;
  site_type: string;
  gsc_connected: boolean;
  gsc_property_url?: string;
  created_at: string;
  latest_session?: CrawlSession;
}

export interface CrawlSession {
  id: string;
  website_id: string;
  started_at: string;
  finished_at?: string;
  crawl_limit: number;
  status: 'queued' | 'running' | 'completed' | 'failed';
  error_message?: string;
  pages_crawled: number;
  pages_failed: number;
  total_issues: number;
  critical_issues: number;
  high_issues: number;
  medium_issues: number;
  low_issues: number;
}

export interface Page {
  id: string;
  crawl_session_id: string;
  url: string;
  page_type: 'article' | 'category' | 'pagination' | 'search' | 'search_pagination' | 'tag' | 'amp' | 'unknown';
  http_status: number;
  title?: string;
  title_length: number;
  meta_robots?: string;
  x_robots_tag?: string;
  canonical_url?: string;
  canonical_status?: number;
  h1_tags: string[];
  h1_count: number;
  word_count: number;
  has_video_embed: boolean;
  schema_types: string[];
  internal_links: string[];
  discovered_from_url?: string;
  crawl_error?: string;
  created_at: string;
}

export interface SeoIssue {
  id: string;
  crawl_session_id: string;
  page_id?: string;
  issue_type: 'canonical' | 'pagination' | 'indexing' | 'amp' | 'structure' | 'technical' | 'search';
  issue_subtype: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  title: string;
  description: string;
  recommended_fix: string;
  evidence_json: Record<string, any>;
  url?: string;
  created_at: string;
}

export interface GscData {
  id: string;
  website_id: string;
  crawl_session_id?: string;
  indexed_pages: number;
  excluded_pages: number;
  coverage_issues: any[];
  fetched_at: string;
}

export interface MozData {
  id: string;
  website_id: string;
  domain_authority: number;
  linking_root_domains: number;
  fetched_at: string;
}
