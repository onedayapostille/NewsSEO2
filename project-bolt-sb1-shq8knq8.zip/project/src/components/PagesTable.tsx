import { useState } from 'react';
import { ExternalLink } from 'lucide-react';
import { Page } from '../types';

interface PagesTableProps {
  pages: Page[];
}

export default function PagesTable({ pages }: PagesTableProps) {
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const pageTypes = Array.from(new Set(pages.map(p => p.page_type)));
  const httpStatuses = Array.from(new Set(pages.map(p => p.http_status)));

  const filteredPages = pages.filter(page => {
    if (filterType !== 'all' && page.page_type !== filterType) return false;
    if (filterStatus !== 'all' && page.http_status.toString() !== filterStatus) return false;
    return true;
  });

  const getPageTypeBadge = (type: string) => {
    const colors: Record<string, string> = {
      article: 'bg-green-100 text-green-800 border-green-200',
      category: 'bg-blue-100 text-blue-800 border-blue-200',
      pagination: 'bg-purple-100 text-purple-800 border-purple-200',
      search: 'bg-orange-100 text-orange-800 border-orange-200',
      search_pagination: 'bg-red-100 text-red-800 border-red-200',
      tag: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      amp: 'bg-pink-100 text-pink-800 border-pink-200',
      unknown: 'bg-slate-100 text-slate-800 border-slate-200'
    };
    return colors[type] || colors.unknown;
  };

  const getStatusColor = (status: number) => {
    if (status >= 200 && status < 300) return 'text-green-600';
    if (status >= 300 && status < 400) return 'text-yellow-600';
    if (status >= 400 && status < 500) return 'text-orange-600';
    if (status >= 500) return 'text-red-600';
    return 'text-slate-600';
  };

  return (
    <div>
      <div className="flex items-center space-x-4 mb-4">
        <div>
          <label className="text-sm font-medium text-slate-700 mr-2">Page Type:</label>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-1 border border-slate-300 rounded-lg text-sm"
          >
            <option value="all">All Types</option>
            {pageTypes.map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="text-sm font-medium text-slate-700 mr-2">HTTP Status:</label>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-1 border border-slate-300 rounded-lg text-sm"
          >
            <option value="all">All Statuses</option>
            {httpStatuses.map(status => (
              <option key={status} value={status}>{status}</option>
            ))}
          </select>
        </div>
        <div className="flex-1 text-right text-sm text-slate-600">
          Showing {filteredPages.length} of {pages.length} pages
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-700 uppercase">URL</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-700 uppercase">Type</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-700 uppercase">Status</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-700 uppercase">Title</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-700 uppercase">H1</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-700 uppercase">Words</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-700 uppercase">Robots</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {filteredPages.map(page => (
              <tr key={page.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 text-sm">
                  <a
                    href={page.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:text-blue-700 flex items-center space-x-1 max-w-md"
                  >
                    <span className="truncate">{page.url}</span>
                    <ExternalLink className="w-3 h-3 flex-shrink-0" />
                  </a>
                </td>
                <td className="px-4 py-3 text-sm">
                  <span className={`px-2 py-1 rounded border text-xs font-medium ${getPageTypeBadge(page.page_type)}`}>
                    {page.page_type}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm">
                  <span className={`font-medium ${getStatusColor(page.http_status)}`}>
                    {page.http_status}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm max-w-xs">
                  <div className="truncate" title={page.title || 'No title'}>
                    {page.title || <span className="text-slate-400">No title</span>}
                  </div>
                </td>
                <td className="px-4 py-3 text-sm text-center">
                  <span className={page.h1_count !== 1 ? 'text-orange-600 font-medium' : ''}>
                    {page.h1_count}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm text-center">
                  <span className={page.word_count < 300 ? 'text-orange-600' : ''}>
                    {page.word_count}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm">
                  <span className="text-xs font-mono">
                    {page.meta_robots || <span className="text-slate-400">-</span>}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {filteredPages.length === 0 && (
          <div className="text-center py-8 text-slate-600">
            No pages found matching the filters
          </div>
        )}
      </div>
    </div>
  );
}
