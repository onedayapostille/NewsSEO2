import { useState } from 'react';
import { ChevronDown, ChevronUp, ExternalLink } from 'lucide-react';
import { SeoIssue } from '../types';

interface IssuesViewProps {
  issues: SeoIssue[];
}

export default function IssuesView({ issues }: IssuesViewProps) {
  const [filterSeverity, setFilterSeverity] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');
  const [expandedIssues, setExpandedIssues] = useState<Set<string>>(new Set());

  const issueTypes = Array.from(new Set(issues.map(i => i.issue_type)));
  const severities = ['critical', 'high', 'medium', 'low'];

  const filteredIssues = issues.filter(issue => {
    if (filterSeverity !== 'all' && issue.severity !== filterSeverity) return false;
    if (filterType !== 'all' && issue.issue_type !== filterType) return false;
    return true;
  });

  const sortedIssues = [...filteredIssues].sort((a, b) => {
    const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
    return severityOrder[a.severity as keyof typeof severityOrder] -
           severityOrder[b.severity as keyof typeof severityOrder];
  });

  const toggleIssue = (id: string) => {
    const newExpanded = new Set(expandedIssues);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedIssues(newExpanded);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      canonical: 'bg-purple-100 text-purple-800',
      pagination: 'bg-indigo-100 text-indigo-800',
      indexing: 'bg-red-100 text-red-800',
      amp: 'bg-pink-100 text-pink-800',
      structure: 'bg-blue-100 text-blue-800',
      technical: 'bg-slate-100 text-slate-800',
      search: 'bg-orange-100 text-orange-800'
    };
    return colors[type] || colors.technical;
  };

  return (
    <div>
      <div className="flex items-center space-x-4 mb-4">
        <div>
          <label className="text-sm font-medium text-slate-700 mr-2">Severity:</label>
          <select
            value={filterSeverity}
            onChange={(e) => setFilterSeverity(e.target.value)}
            className="px-3 py-1 border border-slate-300 rounded-lg text-sm"
          >
            <option value="all">All Severities</option>
            {severities.map(severity => (
              <option key={severity} value={severity}>{severity}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="text-sm font-medium text-slate-700 mr-2">Type:</label>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-1 border border-slate-300 rounded-lg text-sm"
          >
            <option value="all">All Types</option>
            {issueTypes.map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>
        <div className="flex-1 text-right text-sm text-slate-600">
          Showing {sortedIssues.length} of {issues.length} issues
        </div>
      </div>

      <div className="space-y-3">
        {sortedIssues.map(issue => {
          const isExpanded = expandedIssues.has(issue.id);
          return (
            <div
              key={issue.id}
              className={`border rounded-lg overflow-hidden ${getSeverityColor(issue.severity)}`}
            >
              <button
                onClick={() => toggleIssue(issue.id)}
                className="w-full px-4 py-3 flex items-center justify-between hover:opacity-75 transition-opacity"
              >
                <div className="flex items-center space-x-3 flex-1 min-w-0">
                  <span className={`px-2 py-1 rounded text-xs font-medium uppercase ${getTypeColor(issue.issue_type)}`}>
                    {issue.issue_type}
                  </span>
                  <span className="font-medium truncate">{issue.title}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-medium uppercase px-2 py-1 rounded border">
                    {issue.severity}
                  </span>
                  {isExpanded ? (
                    <ChevronUp className="w-5 h-5 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 flex-shrink-0" />
                  )}
                </div>
              </button>

              {isExpanded && (
                <div className="px-4 pb-4 space-y-3 border-t">
                  {issue.url && (
                    <div>
                      <p className="text-xs font-medium uppercase opacity-75 mb-1">Affected URL</p>
                      <a
                        href={issue.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm flex items-center space-x-1 hover:underline"
                      >
                        <span className="truncate">{issue.url}</span>
                        <ExternalLink className="w-3 h-3 flex-shrink-0" />
                      </a>
                    </div>
                  )}

                  <div>
                    <p className="text-xs font-medium uppercase opacity-75 mb-1">Description</p>
                    <p className="text-sm">{issue.description}</p>
                  </div>

                  <div>
                    <p className="text-xs font-medium uppercase opacity-75 mb-1">Recommended Fix</p>
                    <p className="text-sm">{issue.recommended_fix}</p>
                  </div>

                  {issue.evidence_json && Object.keys(issue.evidence_json).length > 0 && (
                    <div>
                      <p className="text-xs font-medium uppercase opacity-75 mb-1">Evidence</p>
                      <div className="bg-white bg-opacity-50 rounded p-2 text-xs font-mono overflow-x-auto">
                        {Object.entries(issue.evidence_json).map(([key, value]) => (
                          <div key={key}>
                            <span className="font-semibold">{key}:</span>{' '}
                            <span>{typeof value === 'object' ? JSON.stringify(value) : String(value)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {sortedIssues.length === 0 && (
        <div className="text-center py-8 text-slate-600">
          No issues found matching the filters
        </div>
      )}
    </div>
  );
}
