import { useState } from 'react';
import { X } from 'lucide-react';

interface CrawlInterfaceProps {
  onStart: (crawlLimit: number) => void;
  onClose: () => void;
}

export default function CrawlInterface({ onStart, onClose }: CrawlInterfaceProps) {
  const [crawlLimit, setCrawlLimit] = useState(10);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onStart(crawlLimit);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-bold text-slate-900">Start New Crawl</h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          <div className="mb-6">
            <label className="block text-sm font-medium text-slate-700 mb-3">
              Crawl Limit
            </label>
            <div className="grid grid-cols-3 gap-3">
              {[10, 25, 50].map(limit => (
                <button
                  key={limit}
                  type="button"
                  onClick={() => setCrawlLimit(limit)}
                  className={`px-4 py-3 rounded-lg border-2 transition-all ${
                    crawlLimit === limit
                      ? 'border-blue-600 bg-blue-50 text-blue-700'
                      : 'border-slate-200 hover:border-slate-300 text-slate-700'
                  }`}
                >
                  <div className="text-2xl font-bold">{limit}</div>
                  <div className="text-xs">pages</div>
                </button>
              ))}
            </div>
            <p className="text-xs text-slate-500 mt-3">
              The crawler will intelligently discover and analyze up to {crawlLimit} pages,
              prioritizing articles, categories, pagination, search pages, and AMP versions.
            </p>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <h3 className="font-semibold text-blue-900 mb-2">What will be analyzed</h3>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>Canonical strategy and implementation</li>
              <li>Pagination rules and configuration</li>
              <li>Search pages and indexing control</li>
              <li>AMP implementation (if detected)</li>
              <li>On-page structure and content quality</li>
              <li>Technical SEO issues</li>
            </ul>
          </div>

          <div className="flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Start Crawl
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
