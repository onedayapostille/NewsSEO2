import { useState, useEffect } from 'react';
import { RefreshCw, Download, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { CrawlSession, Page, SeoIssue } from '../types';
import { api } from '../api';
import PagesTable from './PagesTable';
import IssuesView from './IssuesView';

interface ResultsDashboardProps {
  session: CrawlSession;
  onRefresh: () => void;
}

export default function ResultsDashboard({ session, onRefresh }: ResultsDashboardProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'pages' | 'issues'>('overview');
  const [pages, setPages] = useState<Page[]>([]);
  const [issues, setIssues] = useState<SeoIssue[]>([]);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    loadData();
  }, [session.id]);

  const loadData = async () => {
    if (session.status !== 'completed') {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const [pagesData, issuesData] = await Promise.all([
        api.getPages(session.id),
        api.getIssues(session.id)
      ]);
      setPages(pagesData);
      setIssues(issuesData);
    } catch (err) {
      console.error('Failed to load data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async (format: 'json' | 'csv') => {
    try {
      setExporting(true);
      const data = await api.exportSession(session.id, format);

      if (format === 'csv') {
        const blob = new Blob([data], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `seo-report-${session.id}.csv`;
        a.click();
      } else {
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `seo-report-${session.id}.json`;
        a.click();
      }
    } catch (err) {
      alert('Failed to export data');
    } finally {
      setExporting(false);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'text-red-600 bg-red-100 border-red-200';
      case 'high': return 'text-orange-600 bg-orange-100 border-orange-200';
      case 'medium': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      case 'low': return 'text-blue-600 bg-blue-100 border-blue-200';
      default: return 'text-slate-600 bg-slate-100 border-slate-200';
    }
  };

  if (session.status === 'queued') {
    return (
      <div className="bg-white rounded-lg shadow-md p-12 text-center">
        <Clock className="w-16 h-16 mx-auto text-slate-400 mb-4" />
        <h3 className="text-xl font-semibold text-slate-900 mb-2">Crawl Queued</h3>
        <p className="text-slate-600">The crawl will start shortly...</p>
      </div>
    );
  }

  if (session.status === 'running') {
    return (
      <div className="bg-white rounded-lg shadow-md p-12 text-center">
        <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600 mx-auto mb-4"></div>
        <h3 className="text-xl font-semibold text-slate-900 mb-2">Crawl in Progress</h3>
        <p className="text-slate-600 mb-4">
          {session.pages_crawled} of {session.crawl_limit} pages crawled
        </p>
        <button
          onClick={onRefresh}
          className="text-blue-600 hover:text-blue-700 font-medium"
        >
          Refresh Status
        </button>
      </div>
    );
  }

  if (session.status === 'failed') {
    return (
      <div className="bg-white rounded-lg shadow-md p-12 text-center">
        <AlertTriangle className="w-16 h-16 mx-auto text-red-500 mb-4" />
        <h3 className="text-xl font-semibold text-slate-900 mb-2">Crawl Failed</h3>
        <p className="text-slate-600 mb-4">{session.error_message || 'An error occurred during crawling'}</p>
        <button
          onClick={onRefresh}
          className="text-blue-600 hover:text-blue-700 font-medium"
        >
          Refresh Status
        </button>
      </div>
    );
  }

  return (
    <div>
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-6 h-6 text-green-500" />
            <h2 className="text-xl font-bold text-slate-900">Crawl Completed</h2>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={onRefresh}
              className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              title="Refresh"
            >
              <RefreshCw className="w-5 h-5" />
            </button>
            <div className="relative group">
              <button
                onClick={() => handleExport('csv')}
                disabled={exporting}
                className="flex items-center space-x-2 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors disabled:opacity-50"
              >
                <Download className="w-4 h-4" />
                <span>Export</span>
              </button>
              <div className="absolute right-0 mt-1 bg-white border border-slate-200 rounded-lg shadow-lg hidden group-hover:block w-32 z-10">
                <button
                  onClick={() => handleExport('csv')}
                  className="w-full text-left px-4 py-2 hover:bg-slate-50 text-sm"
                >
                  CSV
                </button>
                <button
                  onClick={() => handleExport('json')}
                  className="w-full text-left px-4 py-2 hover:bg-slate-50 text-sm"
                >
                  JSON
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-slate-50 rounded-lg p-4">
            <p className="text-sm text-slate-600 mb-1">Pages Crawled</p>
            <p className="text-3xl font-bold text-slate-900">{session.pages_crawled}</p>
          </div>
          <div className="bg-slate-50 rounded-lg p-4">
            <p className="text-sm text-slate-600 mb-1">Total Issues</p>
            <p className="text-3xl font-bold text-slate-900">{session.total_issues}</p>
          </div>
          <div className={`rounded-lg p-4 border ${getSeverityColor('critical')}`}>
            <p className="text-sm mb-1 opacity-75">Critical</p>
            <p className="text-3xl font-bold">{session.critical_issues}</p>
          </div>
          <div className={`rounded-lg p-4 border ${getSeverityColor('high')}`}>
            <p className="text-sm mb-1 opacity-75">High</p>
            <p className="text-3xl font-bold">{session.high_issues}</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md mb-6">
        <div className="border-b border-slate-200">
          <nav className="flex space-x-8 px-6">
            {(['overview', 'pages', 'issues'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`py-4 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div>
                <h3 className="font-semibold text-slate-900 mb-3">Issue Breakdown</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {[
                    { severity: 'critical', count: session.critical_issues },
                    { severity: 'high', count: session.high_issues },
                    { severity: 'medium', count: session.medium_issues },
                    { severity: 'low', count: session.low_issues }
                  ].map(({ severity, count }) => (
                    <div key={severity} className={`rounded-lg p-4 border ${getSeverityColor(severity)}`}>
                      <p className="text-sm capitalize opacity-75">{severity} Priority</p>
                      <p className="text-2xl font-bold mt-1">{count}</p>
                    </div>
                  ))}
                </div>
              </div>

              {loading ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : (
                <>
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-3">Page Types Discovered</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {Object.entries(
                        pages.reduce((acc, page) => {
                          acc[page.page_type] = (acc[page.page_type] || 0) + 1;
                          return acc;
                        }, {} as Record<string, number>)
                      ).map(([type, count]) => (
                        <div key={type} className="bg-slate-50 rounded-lg p-3">
                          <p className="text-xs text-slate-600 capitalize">{type.replace('_', ' ')}</p>
                          <p className="text-xl font-bold text-slate-900">{count}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {issues.length > 0 && (
                    <div>
                      <h3 className="font-semibold text-slate-900 mb-3">Top Issues</h3>
                      <div className="space-y-2">
                        {issues.slice(0, 5).map(issue => (
                          <div key={issue.id} className={`p-3 rounded-lg border ${getSeverityColor(issue.severity)}`}>
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <p className="font-medium">{issue.title}</p>
                                {issue.url && <p className="text-sm mt-1 opacity-75 truncate">{issue.url}</p>}
                              </div>
                              <span className="text-xs font-medium uppercase px-2 py-1 rounded">
                                {issue.severity}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          {activeTab === 'pages' && (
            loading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              </div>
            ) : (
              <PagesTable pages={pages} />
            )
          )}

          {activeTab === 'issues' && (
            loading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              </div>
            ) : (
              <IssuesView issues={issues} />
            )
          )}
        </div>
      </div>
    </div>
  );
}
