import { Globe, Trash2, Eye, Clock, AlertTriangle, CheckCircle } from 'lucide-react';
import { Website } from '../types';

interface DashboardProps {
  websites: Website[];
  onSelectWebsite: (id: string) => void;
  onDeleteWebsite: (id: string) => void;
}

export default function Dashboard({ websites, onSelectWebsite, onDeleteWebsite }: DashboardProps) {
  if (websites.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="bg-white rounded-lg shadow-md p-12 max-w-md mx-auto">
          <Globe className="w-16 h-16 mx-auto text-slate-400 mb-4" />
          <h3 className="text-xl font-semibold text-slate-900 mb-2">No websites yet</h3>
          <p className="text-slate-600 mb-6">
            Add your first website to start analyzing its SEO performance
          </p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900">Your Websites</h2>
        <p className="text-slate-600 mt-1">{websites.length} website{websites.length !== 1 ? 's' : ''} being monitored</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {websites.map(website => (
          <div
            key={website.id}
            className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow overflow-hidden"
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3 flex-1 min-w-0">
                  <div className="bg-blue-100 p-2 rounded-lg flex-shrink-0">
                    <Globe className="w-5 h-5 text-blue-600" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="font-semibold text-slate-900 truncate">
                      {website.display_name}
                    </h3>
                    <p className="text-sm text-slate-600 truncate">{website.domain}</p>
                  </div>
                </div>
              </div>

              {website.latest_session ? (
                <div className="space-y-3">
                  <div className="flex items-center space-x-2 text-sm">
                    {website.latest_session.status === 'completed' ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : website.latest_session.status === 'running' ? (
                      <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
                    ) : website.latest_session.status === 'failed' ? (
                      <AlertTriangle className="w-4 h-4 text-red-500" />
                    ) : (
                      <Clock className="w-4 h-4 text-slate-400" />
                    )}
                    <span className="text-slate-600 capitalize">{website.latest_session.status}</span>
                  </div>

                  {website.latest_session.status === 'completed' && (
                    <div className="grid grid-cols-2 gap-2 pt-3 border-t">
                      <div>
                        <p className="text-xs text-slate-500">Pages Crawled</p>
                        <p className="text-lg font-semibold text-slate-900">{website.latest_session.pages_crawled}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Total Issues</p>
                        <p className="text-lg font-semibold text-slate-900">{website.latest_session.total_issues}</p>
                      </div>
                      {website.latest_session.critical_issues > 0 && (
                        <div className="col-span-2">
                          <div className="bg-red-50 border border-red-200 rounded px-2 py-1">
                            <span className="text-sm font-medium text-red-800">
                              {website.latest_session.critical_issues} Critical Issue{website.latest_session.critical_issues !== 1 ? 's' : ''}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="text-xs text-slate-500 pt-2">
                    Last crawl: {new Date(website.latest_session.started_at).toLocaleDateString()}
                  </div>
                </div>
              ) : (
                <div className="text-sm text-slate-500 py-4">
                  No crawls yet
                </div>
              )}
            </div>

            <div className="bg-slate-50 px-6 py-3 flex items-center justify-between border-t">
              <button
                onClick={() => onSelectWebsite(website.id)}
                className="flex items-center space-x-1 text-blue-600 hover:text-blue-700 font-medium text-sm transition-colors"
              >
                <Eye className="w-4 h-4" />
                <span>View Details</span>
              </button>
              <button
                onClick={() => onDeleteWebsite(website.id)}
                className="text-red-600 hover:text-red-700 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
