import { useState, useEffect } from 'react';
import { ArrowLeft, Play, Trash2, RefreshCw } from 'lucide-react';
import { Website, CrawlSession } from '../types';
import { api } from '../api';
import CrawlInterface from './CrawlInterface';
import ResultsDashboard from './ResultsDashboard';

interface WebsiteDetailProps {
  websiteId: string;
  onBack: () => void;
  onDelete: (id: string) => void;
}

export default function WebsiteDetail({ websiteId, onBack, onDelete }: WebsiteDetailProps) {
  const [website, setWebsite] = useState<Website | null>(null);
  const [sessions, setSessions] = useState<CrawlSession[]>([]);
  const [selectedSession, setSelectedSession] = useState<CrawlSession | null>(null);
  const [showCrawlInterface, setShowCrawlInterface] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadWebsite();
  }, [websiteId]);

  useEffect(() => {
    if (selectedSession && (selectedSession.status === 'running' || selectedSession.status === 'queued')) {
      const interval = setInterval(() => {
        refreshSession();
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [selectedSession]);

  const loadWebsite = async () => {
    try {
      setLoading(true);
      const data = await api.getWebsite(websiteId);
      setWebsite(data);
      setSessions(data.sessions || []);
      if (data.sessions && data.sessions.length > 0) {
        setSelectedSession(data.sessions[0]);
      }
    } catch (err) {
      console.error('Failed to load website:', err);
    } finally {
      setLoading(false);
    }
  };

  const refreshSession = async () => {
    if (!selectedSession) return;
    try {
      const updatedSession = await api.getCrawlSession(selectedSession.id);
      setSelectedSession(updatedSession);
      setSessions(prev => prev.map(s => s.id === updatedSession.id ? updatedSession : s));
    } catch (err) {
      console.error('Failed to refresh session:', err);
    }
  };

  const handleStartCrawl = async (crawlLimit: number) => {
    try {
      const newSession = await api.startCrawl(websiteId, crawlLimit);
      setSessions(prev => [newSession, ...prev]);
      setSelectedSession(newSession);
      setShowCrawlInterface(false);
    } catch (err) {
      alert('Failed to start crawl');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!website) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-600">Website not found</p>
        <button onClick={onBack} className="mt-4 text-blue-600 hover:text-blue-700">
          Go Back
        </button>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-slate-600 hover:text-slate-900 mb-4 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Dashboard</span>
        </button>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">{website.display_name}</h1>
              <p className="text-slate-600 mt-1">{website.domain}</p>
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setShowCrawlInterface(true)}
                className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors shadow-md"
              >
                <Play className="w-5 h-5" />
                <span>New Crawl</span>
              </button>
              <button
                onClick={() => onDelete(websiteId)}
                className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {sessions.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <h2 className="font-semibold text-slate-900 mb-3">Crawl History</h2>
          <div className="flex items-center space-x-2 overflow-x-auto pb-2">
            {sessions.map(session => (
              <button
                key={session.id}
                onClick={() => setSelectedSession(session)}
                className={`flex-shrink-0 px-4 py-2 rounded-lg border transition-all ${
                  selectedSession?.id === session.id
                    ? 'border-blue-600 bg-blue-50 text-blue-700'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700'
                }`}
              >
                <div className="text-sm font-medium">
                  {new Date(session.started_at).toLocaleDateString()}
                </div>
                <div className="text-xs text-slate-500 capitalize">{session.status}</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {showCrawlInterface && (
        <CrawlInterface
          onStart={handleStartCrawl}
          onClose={() => setShowCrawlInterface(false)}
        />
      )}

      {selectedSession ? (
        <ResultsDashboard
          session={selectedSession}
          onRefresh={refreshSession}
        />
      ) : (
        <div className="bg-white rounded-lg shadow-md p-12 text-center">
          <p className="text-slate-600 mb-4">No crawls yet</p>
          <button
            onClick={() => setShowCrawlInterface(true)}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Start Your First Crawl
          </button>
        </div>
      )}
    </div>
  );
}
