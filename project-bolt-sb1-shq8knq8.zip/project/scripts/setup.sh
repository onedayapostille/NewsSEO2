#!/bin/bash

# News SEO Analyzer - First Time Setup Script
# Installs dependencies and configures the project

set -e

echo ""
echo "========================================="
echo "  News SEO Analyzer - Setup"
echo "========================================="
echo ""

# Check Node.js version
echo "Checking Node.js version..."
NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)

if [ "$NODE_VERSION" -lt 18 ]; then
  echo "❌ Node.js 18 or higher is required"
  echo "   Current version: $(node --version)"
  exit 1
fi

echo "✓ Node.js version OK: $(node --version)"
echo ""

# Install frontend dependencies
echo "📦 Installing frontend dependencies..."
npm install
echo ""

# Install backend dependencies
echo "📦 Installing backend dependencies..."
cd server
npm install
cd ..
echo ""

# Check for .env file
if [ ! -f ".env" ]; then
  echo "⚠️  No .env file found"
  echo ""
  echo "Creating .env from .env.example..."
  cp .env.example .env
  echo ""
  echo "✓ .env file created"
  echo ""
  echo "⚠️  IMPORTANT: Edit .env and add your configuration:"
  echo "   - Supabase URL and keys"
  echo "   - API URL (for production deployment)"
  echo "   - Optional: GSC, Moz, OpenAI credentials"
  echo ""
else
  echo "✓ .env file exists"
  echo ""
fi

echo "========================================="
echo "  Setup Complete!"
echo "========================================="
echo ""
echo "Next steps:"
echo ""
echo "  1. Edit .env with your configuration"
echo "  2. Start the backend:  npm run server"
echo "  3. Start the frontend: npm run dev"
echo "  4. Run smoke tests:    npm run test:smoke"
echo ""
echo "For detailed instructions, see QUICKSTART.md"
echo ""
