#!/bin/bash

# Environment Variables Checker
# Validates that required environment variables are set

set -e

source .env 2>/dev/null || true

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

ERRORS=0
WARNINGS=0

echo ""
echo "========================================="
echo "  Environment Configuration Check"
echo "========================================="
echo ""

# Required variables
echo "Required variables:"
echo ""

check_required() {
  local var_name=$1
  local var_value=$(eval echo \$$var_name)

  if [ -z "$var_value" ]; then
    echo -e "  ${RED}✗${NC} $var_name: ${RED}MISSING${NC}"
    ERRORS=$((ERRORS + 1))
  else
    echo -e "  ${GREEN}✓${NC} $var_name: set"
  fi
}

check_required "VITE_SUPABASE_URL"
check_required "VITE_SUPABASE_ANON_KEY"
check_required "VITE_API_URL"
check_required "PORT"

echo ""
echo "Optional variables:"
echo ""

check_optional() {
  local var_name=$1
  local var_value=$(eval echo \$$var_name)

  if [ -z "$var_value" ]; then
    echo -e "  ${YELLOW}○${NC} $var_name: not set"
  else
    echo -e "  ${GREEN}✓${NC} $var_name: set"
  fi
}

check_optional "CRAWL_LIMIT_DEFAULT"
check_optional "GSC_CLIENT_ID"
check_optional "GSC_CLIENT_SECRET"
check_optional "GSC_REDIRECT_URI"
check_optional "MOZ_ACCESS_ID"
check_optional "MOZ_SECRET_KEY"
check_optional "OPENAI_API_KEY"
check_optional "OPENAI_MODEL"

echo ""
echo "Feature flags:"
echo ""

check_feature() {
  local var_name=$1
  local var_value=$(eval echo \$$var_name)

  if [ "$var_value" = "true" ]; then
    echo -e "  ${GREEN}✓${NC} $var_name: ${GREEN}enabled${NC}"
  else
    echo -e "  ${YELLOW}○${NC} $var_name: disabled"
  fi
}

check_feature "ENABLE_GSC"
check_feature "ENABLE_MOZ"
check_feature "ENABLE_OPENAI"

echo ""
echo "========================================="

if [ $ERRORS -eq 0 ]; then
  echo -e "${GREEN}✓ Configuration valid${NC}"
  echo "========================================="
  echo ""
  exit 0
else
  echo -e "${RED}✗ Configuration has errors${NC}"
  echo "========================================="
  echo ""
  echo "Fix the missing required variables in .env"
  echo ""
  exit 1
fi
