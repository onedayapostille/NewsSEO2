#!/bin/bash

# News SEO Analyzer - Smoke Test Script
# Verifies that the backend is running and responding correctly

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

API_URL="${VITE_API_URL:-http://localhost:3001}"
PASSED=0
FAILED=0

echo ""
echo "========================================="
echo "  News SEO Analyzer - Smoke Test"
echo "========================================="
echo ""
echo "Testing API at: $API_URL"
echo ""

# Test 1: Health endpoint
echo -n "Test 1: Health check endpoint... "
HEALTH_RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" "$API_URL/health" 2>/dev/null || echo "000")

if [ "$HEALTH_RESPONSE" = "200" ] || [ "$HEALTH_RESPONSE" = "503" ]; then
  echo -e "${GREEN}PASS${NC} (HTTP $HEALTH_RESPONSE)"
  PASSED=$((PASSED + 1))

  # Get detailed health info
  HEALTH_DATA=$(curl -s "$API_URL/health" 2>/dev/null || echo "{}")
  echo "   $(echo $HEALTH_DATA | grep -o '"database":"[^"]*"' || echo 'Database: unknown')"
else
  echo -e "${RED}FAIL${NC} (HTTP $HEALTH_RESPONSE)"
  echo "   Backend not responding"
  FAILED=$((FAILED + 1))
fi

# Test 2: Websites API
echo -n "Test 2: Websites API endpoint... "
WEBSITES_RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" "$API_URL/api/websites" 2>/dev/null || echo "000")

if [ "$WEBSITES_RESPONSE" = "200" ]; then
  echo -e "${GREEN}PASS${NC} (HTTP $WEBSITES_RESPONSE)"
  PASSED=$((PASSED + 1))
else
  echo -e "${RED}FAIL${NC} (HTTP $WEBSITES_RESPONSE)"
  FAILED=$((FAILED + 1))
fi

# Test 3: Integration status
echo -n "Test 3: Integration status endpoint... "
INTEGRATIONS_RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" "$API_URL/api/verify/integrations" 2>/dev/null || echo "000")

if [ "$INTEGRATIONS_RESPONSE" = "200" ]; then
  echo -e "${GREEN}PASS${NC} (HTTP $INTEGRATIONS_RESPONSE)"
  PASSED=$((PASSED + 1))

  # Show enabled features
  FEATURES=$(curl -s "$API_URL/api/verify/integrations" 2>/dev/null || echo "{}")
  echo "   Integrations:"
  echo "   $(echo $FEATURES | grep -o '"gsc":{[^}]*}' | grep -o '"enabled":[^,}]*' || echo 'GSC: unknown')"
  echo "   $(echo $FEATURES | grep -o '"moz":{[^}]*}' | grep -o '"enabled":[^,}]*' || echo 'Moz: unknown')"
  echo "   $(echo $FEATURES | grep -o '"openai":{[^}]*}' | grep -o '"enabled":[^,}]*' || echo 'OpenAI: unknown')"
else
  echo -e "${RED}FAIL${NC} (HTTP $INTEGRATIONS_RESPONSE)"
  FAILED=$((FAILED + 1))
fi

# Test 4: CORS headers
echo -n "Test 4: CORS headers present... "
CORS_HEADER=$(curl -s -I "$API_URL/health" 2>/dev/null | grep -i "access-control-allow-origin" || echo "")

if [ ! -z "$CORS_HEADER" ]; then
  echo -e "${GREEN}PASS${NC}"
  PASSED=$((PASSED + 1))
else
  echo -e "${YELLOW}WARN${NC} (CORS headers not found)"
  PASSED=$((PASSED + 1))  # Not a critical failure
fi

# Test 5: 404 handling
echo -n "Test 5: 404 error handling... "
NOT_FOUND_RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" "$API_URL/api/nonexistent" 2>/dev/null || echo "000")

if [ "$NOT_FOUND_RESPONSE" = "404" ]; then
  echo -e "${GREEN}PASS${NC} (HTTP $NOT_FOUND_RESPONSE)"
  PASSED=$((PASSED + 1))
else
  echo -e "${RED}FAIL${NC} (HTTP $NOT_FOUND_RESPONSE)"
  FAILED=$((FAILED + 1))
fi

echo ""
echo "========================================="
echo "  Results"
echo "========================================="
echo ""
echo -e "Tests passed: ${GREEN}$PASSED${NC}"
echo -e "Tests failed: ${RED}$FAILED${NC}"
echo ""

if [ $FAILED -eq 0 ]; then
  echo -e "${GREEN}✓ All tests passed!${NC}"
  echo ""
  exit 0
else
  echo -e "${RED}✗ Some tests failed${NC}"
  echo ""
  echo "Troubleshooting:"
  echo "  1. Ensure backend is running: npm run server"
  echo "  2. Check .env configuration"
  echo "  3. Verify database connection"
  echo ""
  exit 1
fi
