# Deployment Guide

This guide provides detailed instructions for deploying the News SEO Analyzer to various hosting platforms.

## Table of Contents

1. [VPS / Cloud Server](#vps--cloud-server)
2. [Railway](#railway)
3. [Render](#render)
4. [Docker / Docker Compose](#docker--docker-compose)
5. [Google Cloud Run](#google-cloud-run)
6. [Environment Variables](#environment-variables)

## VPS / Cloud Server

### Requirements

- Ubuntu 20.04+ or similar Linux distribution
- Node.js 18+
- nginx
- PM2 (process manager)
- SSL certificate (optional but recommended)

### Step-by-Step Deployment

#### 1. Prepare the Server

```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Install Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Install nginx
sudo apt install -y nginx

# Install PM2 globally
sudo npm install -g pm2
```

#### 2. Upload Project Files

```bash
# Create directory
sudo mkdir -p /var/www/seo-analyzer
sudo chown $USER:$USER /var/www/seo-analyzer

# Upload project files (using scp, git, or rsync)
# Example with git:
cd /var/www/seo-analyzer
git clone your-repo-url .
```

#### 3. Install Dependencies

```bash
cd /var/www/seo-analyzer

# Install frontend dependencies
npm install

# Install backend dependencies
cd server
npm install
cd ..
```

#### 4. Configure Environment Variables

```bash
# Edit .env file with production values
nano .env
```

Update these variables:
```env
VITE_API_URL=https://your-domain.com
PORT=3001
```

#### 5. Build Frontend

```bash
npm run build
```

#### 6. Start Backend with PM2

```bash
cd server
pm2 start index.js --name seo-api
pm2 save
pm2 startup
```

#### 7. Configure nginx

Create nginx configuration:

```bash
sudo nano /etc/nginx/sites-available/seo-analyzer
```

Add this configuration:

```nginx
server {
    listen 80;
    server_name your-domain.com;

    # Frontend - serve built files
    location / {
        root /var/www/seo-analyzer/dist;
        try_files $uri $uri/ /index.html;
        add_header Cache-Control "public, max-age=31536000";
    }

    # Backend API proxy
    location /api {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # Health check endpoint
    location /health {
        proxy_pass http://localhost:3001/health;
    }
}
```

Enable the site:

```bash
sudo ln -s /etc/nginx/sites-available/seo-analyzer /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

#### 8. Set Up SSL with Let's Encrypt (Optional but Recommended)

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

#### 9. Set Up Automatic Updates (Optional)

```bash
# Create update script
nano /var/www/seo-analyzer/update.sh
```

Add this content:

```bash
#!/bin/bash
cd /var/www/seo-analyzer
git pull
npm install
cd server
npm install
cd ..
npm run build
pm2 restart seo-api
```

Make it executable:

```bash
chmod +x update.sh
```

---

## Railway

Railway provides simple deployment with automatic HTTPS.

### Steps

#### 1. Install Railway CLI

```bash
npm install -g @railway/cli
```

#### 2. Login to Railway

```bash
railway login
```

#### 3. Initialize Project

```bash
cd /path/to/seo-analyzer
railway init
```

#### 4. Set Environment Variables

In Railway dashboard:
- Go to your project
- Click "Variables"
- Add all variables from `.env`
- Important: Set `VITE_API_URL` to your Railway deployment URL

#### 5. Deploy

```bash
railway up
```

Railway will automatically:
- Detect Node.js
- Install dependencies
- Build the frontend
- Start the backend

#### 6. Get Your URL

```bash
railway domain
```

#### 7. Update Environment and Redeploy

After getting your URL, update `VITE_API_URL` in Railway variables and redeploy.

---

## Render

Render provides free hosting for web services.

### Steps

#### 1. Connect Git Repository

- Go to [render.com](https://render.com)
- Sign up / Log in
- Click "New +" → "Web Service"
- Connect your Git repository

#### 2. Configure Service

Render will detect `render.yaml` automatically. If not:

- **Name**: seo-analyzer
- **Environment**: Node
- **Build Command**: `npm install && cd server && npm install && cd .. && npm run build`
- **Start Command**: `cd server && npm start`

#### 3. Set Environment Variables

Add these in Render dashboard:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `PORT` (set to 3001)
- `CRAWL_LIMIT_DEFAULT` (set to 10)

#### 4. Deploy

Click "Create Web Service"

Render will:
- Clone your repository
- Install dependencies
- Build the project
- Start the server

#### 5. Get Your URL

Render provides a URL like: `https://your-app.onrender.com`

#### 6. Update Frontend API URL

Add to environment variables:
- `VITE_API_URL` with your Render URL

Redeploy to apply changes.

---

## Docker / Docker Compose

### Local Docker Deployment

#### 1. Build Image

```bash
docker build -t seo-analyzer .
```

#### 2. Run Container

```bash
docker run -d \
  --name seo-analyzer \
  -p 3001:3001 \
  --env-file .env \
  seo-analyzer
```

### Docker Compose Deployment

#### 1. Start Services

```bash
docker-compose up -d
```

#### 2. View Logs

```bash
docker-compose logs -f
```

#### 3. Stop Services

```bash
docker-compose down
```

### Production Docker Deployment

For production, use a reverse proxy like nginx or Traefik in front of the container.

Example with nginx:

```yaml
version: '3.8'

services:
  seo-analyzer:
    build: .
    environment:
      - PORT=3001
    env_file:
      - .env
    restart: unless-stopped
    networks:
      - web

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - seo-analyzer
    networks:
      - web

networks:
  web:
```

---

## Google Cloud Run

Google Cloud Run provides serverless container hosting.

### Prerequisites

- Google Cloud account
- gcloud CLI installed
- Docker installed locally

### Steps

#### 1. Set Up Google Cloud Project

```bash
# Login
gcloud auth login

# Set project
gcloud config set project YOUR_PROJECT_ID

# Enable required APIs
gcloud services enable run.googleapis.com
gcloud services enable cloudbuild.googleapis.com
```

#### 2. Build and Push Container

```bash
# Build container
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/seo-analyzer

# Or with Docker
docker build -t gcr.io/YOUR_PROJECT_ID/seo-analyzer .
docker push gcr.io/YOUR_PROJECT_ID/seo-analyzer
```

#### 3. Deploy to Cloud Run

```bash
gcloud run deploy seo-analyzer \
  --image gcr.io/YOUR_PROJECT_ID/seo-analyzer \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --port 3001 \
  --set-env-vars "VITE_SUPABASE_URL=your_url,VITE_SUPABASE_ANON_KEY=your_key,PORT=3001"
```

#### 4. Get Service URL

```bash
gcloud run services describe seo-analyzer --region us-central1 --format 'value(status.url)'
```

#### 5. Update Frontend API URL

Update environment variable:

```bash
gcloud run services update seo-analyzer \
  --region us-central1 \
  --set-env-vars "VITE_API_URL=https://your-cloud-run-url.run.app"
```

---

## Environment Variables

### Required Variables

```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key
VITE_API_URL=https://your-api-url.com
PORT=3001
CRAWL_LIMIT_DEFAULT=10
```

### Optional Variables (GSC Integration)

```env
GSC_CLIENT_ID=your_google_client_id
GSC_CLIENT_SECRET=your_google_client_secret
GSC_REDIRECT_URI=https://your-domain.com/gsc/callback
```

### Optional Variables (Moz Integration)

```env
MOZ_ACCESS_ID=your_moz_access_id
MOZ_SECRET_KEY=your_moz_secret_key
```

### Platform-Specific Notes

#### Railway
- Set variables in Railway dashboard under "Variables"
- Variables are automatically injected into the container

#### Render
- Set variables in Render dashboard under "Environment"
- Mark sensitive variables as "Secret"

#### Google Cloud Run
- Set variables using `--set-env-vars` flag
- Or use Secret Manager for sensitive data

#### Docker
- Use `--env-file` flag or docker-compose `env_file`
- Never commit `.env` to version control

---

## Post-Deployment Checklist

- [ ] Verify backend is accessible at `/health` endpoint
- [ ] Test website creation
- [ ] Start a test crawl (use crawl limit of 10)
- [ ] Verify results are displayed correctly
- [ ] Test export functionality (CSV and JSON)
- [ ] Check browser console for errors
- [ ] Verify API requests are going to correct URL
- [ ] Test on mobile devices
- [ ] Set up monitoring/alerts (optional)
- [ ] Configure backups for database (Supabase handles this)

---

## Troubleshooting

### Frontend can't connect to backend

**Solution**: Check `VITE_API_URL` matches your backend URL exactly.

### CORS errors

**Solution**: Verify backend is running and CORS is configured correctly in `server/index.js`.

### Build fails

**Solution**:
```bash
# Clear caches
rm -rf node_modules server/node_modules dist
npm install
cd server && npm install && cd ..
npm run build
```

### Container exits immediately

**Solution**: Check logs for errors:
```bash
docker logs seo-analyzer
# or
docker-compose logs seo-analyzer
```

### Database connection fails

**Solution**: Verify Supabase credentials in environment variables are correct.

---

## Updating the Application

### VPS Deployment

```bash
cd /var/www/seo-analyzer
git pull
npm install
cd server && npm install && cd ..
npm run build
pm2 restart seo-api
```

### Railway / Render

Simply push to your connected Git repository. Auto-deployment will handle the rest.

### Docker

```bash
# Rebuild and restart
docker-compose down
docker-compose build
docker-compose up -d
```

---

## Monitoring

### PM2 Monitoring (VPS)

```bash
# View logs
pm2 logs seo-api

# Monitor resources
pm2 monit

# View status
pm2 status
```

### Docker Monitoring

```bash
# View logs
docker-compose logs -f seo-analyzer

# View resource usage
docker stats
```

### Health Checks

All deployments should monitor the `/health` endpoint:

```bash
curl https://your-domain.com/health
```

Expected response:
```json
{
  "status": "healthy",
  "timestamp": "2024-02-09T12:00:00.000Z"
}
```

---

## Security Considerations

1. **Always use HTTPS in production**
2. **Keep dependencies updated**: Run `npm audit` regularly
3. **Secure environment variables**: Never commit `.env` to Git
4. **Database access**: Supabase handles security, but verify RLS policies
5. **Rate limiting**: Consider adding rate limiting for API endpoints
6. **Firewall**: Only expose ports 80 and 443 on VPS deployments

---

## Support

For deployment issues, check:
1. Application logs
2. Backend server logs
3. Database connectivity
4. Environment variable configuration
5. Network/firewall settings
