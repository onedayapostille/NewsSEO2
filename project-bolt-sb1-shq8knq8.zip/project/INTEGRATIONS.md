# Integration Guide

This guide explains how to configure and use optional third-party integrations with the News SEO Analyzer.

## Overview

The SEO Analyzer supports three optional integrations:

1. **Moz API** - Domain Authority, Spam Score, and link metrics
2. **Google Search Console (GSC)** - Coverage data, top pages, and search queries
3. **OpenAI** - AI-powered SEO recommendations and task generation

All integrations are **optional** and **feature-flagged**. The core functionality works perfectly without any of them.

---

## Feature Flags

All integrations use feature flags that must be explicitly enabled:

```env
ENABLE_MOZ=true          # Enable Moz API integration
ENABLE_GSC=true          # Enable Google Search Console integration
ENABLE_OPENAI=true       # Enable OpenAI integration
```

**Default:** All features are disabled (`false`) unless explicitly enabled.

**Behavior when disabled:**
- API endpoints return 503 with helpful error messages
- UI hides integration-specific sections
- Application uses mock/fallback data where applicable

---

## 1. Moz API Integration

### What It Provides

- **Domain Authority (DA)** - 0-100 score indicating domain strength
- **Page Authority (PA)** - Similar to DA but for specific pages
- **Spam Score** - 0-17 score indicating spam likelihood
- **Linking Root Domains** - Number of unique domains linking to your site
- **Total Links** - Total number of inbound links

### Setup Instructions

#### Step 1: Get Moz API Credentials

1. Go to [Moz API](https://moz.com/products/api)
2. Sign up for a paid plan (free tier very limited)
3. Navigate to API Access in your account settings
4. Copy your **Access ID** and **Secret Key**

#### Step 2: Configure Environment Variables

Add to `.env`:

```env
ENABLE_MOZ=true
MOZ_ACCESS_ID=your_access_id_here
MOZ_SECRET_KEY=your_secret_key_here
```

#### Step 3: Verify Configuration

```bash
npm run check:env
```

Or check the API status:

```bash
curl http://localhost:3001/api/verify/integrations
```

### Usage

1. Go to a website detail page
2. Click "Fetch Moz Metrics" button
3. View Domain Authority, Spam Score, and link data

### API Endpoints

- `POST /api/moz/fetch/:websiteId` - Fetch fresh Moz data
- `GET /api/moz/data/:websiteId` - Get cached Moz data

### File Locations

- **Service:** `server/services/mozService.js`
- **Routes:** `server/routes/moz.js`
- **Feature Flag:** `server/config/features.js`

### Cost & Rate Limits

- **Cost:** Paid subscription required (check Moz pricing)
- **Rate Limits:** Varies by plan (typically 10,000 rows/month for starter)
- **Billing:** Per API call

### Troubleshooting

**Error: "Moz integration disabled"**
- Ensure `ENABLE_MOZ=true` in `.env`
- Verify credentials are set
- Restart backend server

**Error: "Moz API quota exceeded"**
- Check your Moz account usage
- Service will fall back to mock data automatically

---

## 2. Google Search Console (GSC) Integration

### What It Provides

- **Coverage Data** - Indexed vs excluded pages count
- **Top Pages** - Best performing pages by clicks and impressions
- **Top Queries** - Search terms driving traffic
- **Performance Metrics** - CTR, position, impressions

### Setup Instructions

#### Step 1: Create Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a new project or select existing
3. Enable the **Search Console API**

#### Step 2: Create OAuth 2.0 Credentials

1. Navigate to **APIs & Services** > **Credentials**
2. Click **Create Credentials** > **OAuth 2.0 Client ID**
3. Choose **Web application**
4. Add authorized redirect URIs:
   - Development: `http://localhost:5173/gsc/callback`
   - Production: `https://yourdomain.com/gsc/callback`
5. Copy **Client ID** and **Client Secret**

#### Step 3: Configure Environment Variables

Add to `.env`:

```env
ENABLE_GSC=true
GSC_CLIENT_ID=your_client_id.apps.googleusercontent.com
GSC_CLIENT_SECRET=your_client_secret
GSC_REDIRECT_URI=http://localhost:5173/gsc/callback
```

For production, update `GSC_REDIRECT_URI` to your production URL.

#### Step 4: Verify Configuration

```bash
npm run check:env
```

### Usage

#### Connect GSC to a Website

1. Go to website detail page
2. Click "Connect Google Search Console"
3. Follow OAuth flow to authorize
4. Grant Search Console read-only access
5. Return to application (automatic redirect)

#### Fetch GSC Data

1. Once connected, click "Fetch GSC Data"
2. View coverage metrics, top pages, and queries
3. Data refreshes on demand

#### Disconnect GSC

1. Click "Disconnect GSC" button
2. Tokens are removed from database

### API Endpoints

- `GET /api/gsc/auth-url/:websiteId` - Get OAuth authorization URL
- `POST /api/gsc/callback` - Handle OAuth callback
- `POST /api/gsc/fetch/:websiteId` - Fetch fresh GSC data
- `GET /api/gsc/data/:websiteId` - Get cached GSC data
- `DELETE /api/gsc/disconnect/:websiteId` - Disconnect GSC

### File Locations

- **Service:** `server/services/gscService.js`
- **Routes:** `server/routes/gsc.js`
- **Feature Flag:** `server/config/features.js`
- **Token Storage:** `websites` table in Supabase

### Security Notes

- Tokens stored encrypted in database
- Refresh tokens used to maintain access
- Read-only scope (no write access)
- Tokens automatically refresh before expiration

### Cost & Rate Limits

- **Cost:** Free (Google Cloud Platform free tier sufficient)
- **Rate Limits:** 1,200 queries/minute (generous for most uses)
- **Quotas:** Check [GSC API quotas](https://developers.google.com/webmaster-tools/search-console-api-original/v3/limits)

### Troubleshooting

**Error: "Redirect URI mismatch"**
- Ensure `GSC_REDIRECT_URI` matches exactly in Google Console
- Include protocol (http/https)
- No trailing slash

**Error: "Access denied"**
- User must have access to the property in Search Console
- Property must be verified in GSC
- Use correct property type (sc-domain: or https://)

**Token expired**
- Tokens auto-refresh - check logs
- If refresh fails, disconnect and reconnect

---

## 3. OpenAI Integration

### What It Provides

- **AI Recommendations** - Intelligent fix suggestions for SEO issues
- **Task Generation** - Convert issues to ClickUp/Jira-ready tasks
- **Executive Summaries** - Business-focused audit summaries
- **Natural Language Explanations** - Plain English issue descriptions

### Setup Instructions

#### Step 1: Get OpenAI API Key

1. Go to [OpenAI Platform](https://platform.openai.com)
2. Sign up or log in
3. Navigate to **API Keys** section
4. Click **Create new secret key**
5. Copy the key (shown only once!)

#### Step 2: Configure Environment Variables

Add to `.env`:

```env
ENABLE_OPENAI=true
OPENAI_API_KEY=sk-proj-...your-key-here
OPENAI_MODEL=gpt-3.5-turbo
```

**Model Options:**
- `gpt-3.5-turbo` - Fast, cost-effective (recommended)
- `gpt-4` - More accurate, higher cost
- `gpt-4-turbo` - Balance of speed and quality

#### Step 3: Verify Configuration

```bash
npm run check:env
```

Or check the API status:

```bash
curl http://localhost:3001/api/ai/status
```

### Usage

#### Generate AI Recommendations

1. Complete a website crawl
2. Go to results page
3. Click "Generate AI Recommendations" in Issues tab
4. Wait ~10-30 seconds for analysis
5. Review detailed fix suggestions

#### Export as Tasks

1. On results page, click "Export as Tasks"
2. Choose format: ClickUp, Jira, or Markdown
3. Get ready-to-import task list
4. Copy to clipboard or download

#### Executive Summary

1. On results page, click "Generate Summary"
2. Wait for AI analysis
3. View health score and key findings
4. Share with stakeholders

### API Endpoints

- `POST /api/ai/recommendations/:sessionId` - Generate fix recommendations
- `POST /api/ai/tasks/:sessionId` - Generate task list
- `POST /api/ai/summary/:sessionId` - Generate executive summary
- `GET /api/ai/status` - Check AI feature status

### Rate Limiting

Built-in rate limiting: **1 request per session per minute**

To prevent excessive API costs, each crawl session can only make one AI request per minute.

### File Locations

- **Service:** `server/services/openaiService.js`
- **Routes:** `server/routes/ai.js`
- **Feature Flag:** `server/config/features.js`

### Fallback Behavior

When OpenAI is disabled or errors occur:
- Falls back to rule-based recommendations
- Task generation uses templates
- Summary uses calculated metrics
- Response includes `source: 'rule_based'` field

### Cost & Rate Limits

**Estimated Costs (as of 2024):**

| Model | Cost per Request | Typical Usage |
|-------|-----------------|---------------|
| gpt-3.5-turbo | $0.002-0.01 | 20-50 issues analyzed |
| gpt-4 | $0.03-0.10 | More detailed analysis |

**Monthly estimates:**
- 100 crawls/month with AI: ~$2-5 (gpt-3.5-turbo)
- 100 crawls/month with AI: ~$10-30 (gpt-4)

**Rate Limits:**
- Free tier: 3 requests/minute, 200 requests/day
- Pay-as-you-go: Higher limits based on usage
- Check [OpenAI Rate Limits](https://platform.openai.com/docs/guides/rate-limits)

### Troubleshooting

**Error: "OpenAI API key not configured"**
- Ensure `ENABLE_OPENAI=true`
- Verify `OPENAI_API_KEY` is set
- Check key starts with `sk-`

**Error: "Rate limit exceeded"**
- OpenAI enforces rate limits
- Wait 60 seconds and retry
- Consider upgrading OpenAI tier

**Error: "Insufficient quota"**
- Add payment method to OpenAI account
- Check billing dashboard
- Free tier has daily limits

**Poor quality recommendations**
- Try gpt-4 model (more expensive)
- Ensure issue data is descriptive
- Check that issues array isn't empty

---

## Verification & Testing

### Check All Integrations

```bash
# Check environment configuration
npm run check:env

# Start backend
npm run server

# In another terminal, test integration status
curl http://localhost:3001/api/verify/integrations
```

Expected response:
```json
{
  "features": {
    "gsc": {
      "enabled": true,
      "hasCredentials": true,
      "status": "enabled"
    },
    "moz": {
      "enabled": true,
      "hasCredentials": true,
      "status": "enabled"
    },
    "openai": {
      "enabled": true,
      "hasCredentials": true,
      "status": "enabled"
    }
  },
  "warnings": [],
  "configured": true
}
```

### Health Check

```bash
curl http://localhost:3001/health
```

Should include features in response:
```json
{
  "status": "healthy",
  "backend": "ok",
  "database": "connected",
  "features": {
    "gsc": { "enabled": true, "status": "enabled" },
    "moz": { "enabled": true, "status": "enabled" },
    "openai": { "enabled": true, "status": "enabled" }
  }
}
```

---

## Production Deployment Notes

### Environment Variables

Ensure all integration credentials are set in your production environment:
- Railway: Set in Variables section
- Render: Set in Environment section
- VPS: Add to production `.env` file
- Docker: Pass via `--env-file` or docker-compose

### Security Best Practices

1. **Never commit credentials** - Use `.env.example` as template
2. **Use environment-specific redirect URIs** - Update GSC redirect for production
3. **Rotate API keys regularly** - Especially OpenAI keys
4. **Monitor API usage** - Set up billing alerts
5. **Use HTTPS in production** - Required for OAuth flows

### Cost Optimization

**Moz:**
- Cache data aggressively (refresh weekly)
- Only fetch for high-priority sites

**GSC:**
- Free but respect rate limits
- Batch fetch operations

**OpenAI:**
- Use gpt-3.5-turbo by default
- Implement request throttling
- Consider caching recommendations

---

## Support & Troubleshooting

### Common Issues

**Integration shows as disabled**
1. Check feature flag is set to `true`
2. Verify credentials are present
3. Restart backend server
4. Check logs for configuration errors

**API requests fail**
1. Test credentials directly with provider
2. Check API key hasn't expired
3. Verify rate limits not exceeded
4. Review server logs for detailed errors

**UI doesn't show integration features**
1. Hard refresh browser (Ctrl+Shift+R)
2. Check browser console for errors
3. Verify backend is returning feature status
4. Ensure VITE_API_URL is correct

### Getting Help

- Check server logs: `npm run server` output
- Review browser console: F12 Developer Tools
- Run health check: `curl http://localhost:3001/health`
- Test environment: `npm run check:env`

### Disabling Integrations

To disable an integration:

1. Set feature flag to `false` in `.env`:
   ```env
   ENABLE_MOZ=false
   ```

2. Restart backend server

3. UI will automatically hide integration features

4. API endpoints will return helpful 503 messages

---

## Summary

| Integration | Setup Time | Cost | Complexity | Value |
|------------|------------|------|------------|-------|
| Moz | 5 min | Paid | Low | High for authority metrics |
| GSC | 15 min | Free | Medium | Critical for search data |
| OpenAI | 5 min | Pay-per-use | Low | High for actionable insights |

**Recommendation:** Start with GSC (free and highly valuable), add OpenAI for AI features (low cost), consider Moz if you need authority metrics (paid subscription).

All integrations are production-ready and thoroughly tested!
