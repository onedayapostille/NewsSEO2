# Quick Start Guide

Get the News SEO Analyzer running in 5 minutes!

**Having issues?** Check [BOOTSTRAP.md](./BOOTSTRAP.md) for detailed troubleshooting.

## Prerequisites

- Node.js 18+ installed
- npm or yarn

## Installation

### 1. Install all dependencies

```bash
npm run install:all
```

This will install both frontend and backend dependencies.

### 2. Start the Backend Server

In your terminal:

```bash
npm run server
```

The backend API will start on `http://localhost:3001`

Keep this terminal running!

### 3. Start the Frontend

In a **new terminal**:

```bash
npm run dev
```

The frontend will start on `http://localhost:5173`

### 4. Access the Application

Open your browser and go to: **http://localhost:5173**

## First Steps

### Add Your First Website

1. Click the "Add Website" button in the top right
2. Enter a domain (e.g., `techcrunch.com`)
3. Optionally add a display name
4. Click "Add Website"

### Run Your First Crawl

1. Click "View Details" on your website
2. Click "New Crawl"
3. Select crawl limit (start with 10 for testing)
4. Click "Start Crawl"
5. Watch the progress (refreshes automatically)

### View Results

Once the crawl completes:
- Check the **Overview** tab for summary statistics
- Go to **Pages** tab to see all crawled pages with filters
- Go to **Issues** tab to see SEO problems with recommended fixes
- Use the **Export** button to download results as CSV or JSON

## What Gets Analyzed

The crawler intelligently discovers:
- Homepage
- Latest articles
- Category pages
- Pagination (page 2)
- Search result pages
- Tag pages
- AMP versions

And checks for:
- Canonical tag issues
- Pagination problems
- Search page indexing
- Content quality
- Technical SEO errors

## Troubleshooting

### "Failed to load websites" error

Make sure the backend server is running:
```bash
npm run server
```

### Port already in use

If port 3001 is busy, edit `.env`:
```env
PORT=3002
VITE_API_URL=http://localhost:3002
```

Restart both servers.

### Build errors

Clear and reinstall:
```bash
rm -rf node_modules server/node_modules
npm run install:all
```

## Next Steps

- Read the [full README](./README.md) for deployment options
- Check [DEPLOYMENT.md](./DEPLOYMENT.md) for production setup
- Configure optional integrations:
  - Google Search Console
  - Moz API

## Support

For issues or questions, check the logs:
- Backend logs appear in the terminal running `npm run server`
- Frontend errors appear in browser console (F12)

## Quick Commands Reference

```bash
# Install everything
npm run install:all

# Start backend
npm run server

# Start frontend (development)
npm run dev

# Build for production
npm run build

# Run type checking
npm run typecheck

# Run linter
npm run lint
```

---

Happy analyzing!
